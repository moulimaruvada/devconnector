
public class Mp4 implements MediaPackage {

	@Override
	public void Fileplay(String fileName) {
		// TODO Auto-generated method stub
		System.out.println("Playing Mp4 file "+fileName);
	}

}
