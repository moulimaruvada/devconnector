
public interface MediaPackage {

	public void Fileplay(String fileName); 
}
