
public class FormatAdapter implements MediaPlayer {

	
	private MediaPackage media;
	
	public FormatAdapter(MediaPackage mediapackage) 	
	{
		media = mediapackage;
		
	}
	@Override
	public void play(String fileName) {
		// TODO Auto-generated method stub
		System.out.println("adapter usage");
		media.Fileplay(fileName);
	}

}
