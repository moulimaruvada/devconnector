
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		MediaPlayer mediaPlayer = new Mp3();
		mediaPlayer.play("premam.mp3");
		
		mediaPlayer = new FormatAdapter(new Mp4());
		mediaPlayer.play("file.mp4");
		
		mediaPlayer = new FormatAdapter(new VLC());
		mediaPlayer.play("file.avi");
		
	}

}
