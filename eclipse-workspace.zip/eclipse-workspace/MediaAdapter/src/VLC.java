
public class VLC implements MediaPackage {

	@Override
	public void Fileplay(String fileName) {
		// TODO Auto-generated method stub
		System.out.println("Playing VLC file "+fileName);
	}

}
