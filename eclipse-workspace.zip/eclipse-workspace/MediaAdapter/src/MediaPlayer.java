
public interface MediaPlayer {

	public void play(String fileName); 
}
