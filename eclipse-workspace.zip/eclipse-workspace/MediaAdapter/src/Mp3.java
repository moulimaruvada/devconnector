
public class Mp3 implements MediaPlayer {

	@Override
	public void play(String fileName) {
		// TODO Auto-generated method stub
		System.out.println("Playing mp3 file"+ fileName);
	}

}
