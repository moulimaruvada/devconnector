import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Set;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

public class Principal {

//	public boolean isItMyBirthday(LocalDateTime dateTime)
//	
//	 {
//		LocalDate now = LocalDate.now(); 
//		return now.getMonth() == dateTime.getMonth() && now.getDayOfMonth() == dateTime.getDayOfMonth();
//	 }
	
	public static void main(String[] args) {
		
//		try {
//			int i=7;
//			int j=0;
//			int z =i/j; 
//			
//		}
//		catch(Exception e)
//		{
//			e.printStackTrace();
//		}
//		finally {
//			
//		}
//		
//		System.out.println("Bye");
		HashMap props = new HashMap();
		props.put("key4","some value");
		props.put("key12","some other value");
		props.put("key15","some  value");
		props.put("key25","yet another value");
		Set s = 	props.keySet();
	}

}
