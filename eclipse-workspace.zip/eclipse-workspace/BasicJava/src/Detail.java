import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Detail {


	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the array: ");	
		String[] array = new String[2];
		String[] array1 = new String[5];
		for(int i=0;i<2;i++)
		{
			array[i]=sc.next();
		}
		for(int i=0;i<1;i++)
		{
			for(int j=i+1;j<array.length;j++)
			{
				if(array[i].compareTo(array[j])>0)
				{
					String temp = array[i];
					array[i]=array[j];
					array[j]=temp;
				}
			}
		}
		
		for(String s:array)
		{
			System.out.println(s);
		}
		
		


	}

	private static void rem(int a, int b) {

		
		// TODO Auto-generated method stub
		
		List<Integer> value = new ArrayList<Integer>();
		for(int i=a;i<=b;i++)
		{
			int flag=0;
			for(int j=2;j<=i/2;j++)
			{
				
				if(i%j==0)
				{
					flag=1;
					break;
					
				}
		
			}
			if(i!=0&&i!=1&&flag==0)
			{
				value.add(i);
				
			}
			
		}
		if(value.size()==0)
		{
			System.out.println("(empty list)");
		}
		else
		{
			for(int s:value)
			{
				System.out.println(s);
			}
		}

	
		
	}

	public static void key(int array[])
	{
		
		for(int i=1;i<array.length;i++)
		{
			int key=array[i];
			int j = i-1;
			
			while(j>=0&&array[j]>key)
			{
				array[j+1]=array[j];
				j=j-1;
				
			}
			array[j+1]=key;
			
			System.out.println((i+1)+"st pass");
			for(int s:array)
			{
				System.out.print(s+" ");	
			}
			System.out.println("");
		}
		for(int s:array)
		{
			System.out.println(s);
		}
		
		
	}
}
