
public class M1 implements Movable {

	@Override
	public void move() {
		// TODO Auto-generated method stub

	}
	
	@Override
	public  void display() {
		
		System.out.println("Hello");  
	
	}

}
