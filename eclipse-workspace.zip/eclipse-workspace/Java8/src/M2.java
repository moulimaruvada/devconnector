
public class M2 implements Movable {

	@Override
	public void move() {
		// TODO Auto-generated method stub

	}

}
