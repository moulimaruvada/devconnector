import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.BiFunction;
import java.util.function.BinaryOperator;

public class MainBinaryOperator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BiFunction<Integer, Float, Float> func = (x,y)->x+y.floatValue();
		
		Float result = func.apply(10, 20.00f);
		System.out.println(result);
		
		List<Integer> integers = Arrays.asList(1,2,3,4,5,6);
	
	
	List<Float> floats = Arrays.asList(10.00f,20.00f,30.00f,40.00f,50.00f,60.00f,70.00f,80.00f,90.00f);
	
	List<Float> floats2 = math(floats,(x,y)->(float)(x+y));
	floats2.forEach(System.out::println);
	
	}

public static <T> List<T> math(List<T> list, BinaryOperator<T> BinaryOperator) {
	List<T> result = new ArrayList<T>();
	
	for (T t : list) {
		result.add(BinaryOperator.apply(t,t));
	}
	return result;
}

}
