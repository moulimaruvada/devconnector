import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class DateTimeAPI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		LocalDate date = LocalDate.now();
		System.out.println(date);
		
		System.out.println(date.format(DateTimeFormatter.ofPattern("d:MMM:uuuu")));
		

	}

}
