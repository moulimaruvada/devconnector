
public class MainClass {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		M1 n = new M1();
		M2 n1 = new M2();
		
		
		n.display();
		
		n1.display();
	}

}
