@FunctionalInterface
public interface Movable {
	
	public void move();
	
	public default void display() {
		System.out.println("hello from display");
	}
	//can we override default methods: yes
	

}
