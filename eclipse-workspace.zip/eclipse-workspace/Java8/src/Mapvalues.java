import java.util.List;
import java.util.TreeMap;
import java.util.stream.Collectors;

public class Mapvalues {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		TreeMap<Integer, String> hashMap = new TreeMap<Integer, String>();
		
		//to add the data in map
		hashMap.put(10,"Mouli");
		hashMap.put(-2,"Maruvada");
		hashMap.put(1000,null);
		hashMap.put(111,"Maru");
		
		List<String> result3 = hashMap.values().stream()
			    .collect(Collectors.toList());
	
			
		System.out.println(result3);

	}

}
