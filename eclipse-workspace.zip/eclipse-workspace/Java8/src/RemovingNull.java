import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class RemovingNull {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
			List<Integer> integers = Arrays.asList(1,23,0,null,4,null,6,7,8,null,9);
			List<Integer> s = integers.stream().filter(e->(e!=null))
					.collect(Collectors.toList());
			System.out.println(s);
		
	}

}
