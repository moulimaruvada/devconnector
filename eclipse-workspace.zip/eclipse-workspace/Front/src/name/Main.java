package name;

public class Main {
	
	public static void main(String[] args) {
		new FrontControl().dispatchRequest("view");
		
	}

}
