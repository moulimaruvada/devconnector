package name;

public class View {
	
	public void show() {
		System.out.println("hello from view");
	}


}