package name;

public class View2 {
	public void show() {
		System.out.println("hello from view2");
	}

}
