package name;

public class Handler {
	
	private View view;
	private View2 view2;
	
	public Handler() {
		// TODO Auto-generated constructor stub
		
		view = new View();
		view2 = new View2();
	}

	
	public void handle(String request) {
		
		if("view".equals(request)) {
			
		view.show();
	}
		else if("view2".equals(request)) {
			view2.show();
		}
}
}