package name;

public class FrontControl {

	
Dispatcher dispatcher = new Dispatcher();
public FrontControl() {
	
	// TODO Auto-generated constructor stub
}

private static FrontControl frontControl;

public static FrontControl getInstance() {
	if(frontControl==null) {
		frontControl = new FrontControl();
		return frontControl;
	}
	return frontControl;
}


public void dispatchRequest(String request) {
	
	dispatcher.dispatch(request);
	
}
}