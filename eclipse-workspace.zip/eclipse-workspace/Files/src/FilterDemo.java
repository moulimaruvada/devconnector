import java.io.File;
import java.io.FilenameFilter;

public class FilterDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String loc = "tmp/sample/test";
		
		File file = new File(loc);
		
//		File files[] = file.listFiles(new MyFilter(".txt"));
		
		for(File f: file.listFiles()) {
			System.out.println(f);
		}
	}
	
	class MyFilter implements FilenameFilter {
		
		String extension;
		public MyFilter(String extension) {
			// TODO Auto-generated constructor stub
			this.extension = extension;
		}

		@Override
		public boolean accept(File arg0, String name) {
			// TODO Auto-generated method stub
			return name.toLowerCase().endsWith(extension);
		}
		
	}
	

}
