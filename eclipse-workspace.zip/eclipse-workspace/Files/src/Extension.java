import java.io.File;
import java.util.Date;

public class Extension {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String fileName = "tmp/sample/test/sample.txt";
		
		File file = new File(fileName);
		System.out.println(file.getName());
		System.out.println(file.getName().substring(file.getName().indexOf("."), file.getName().length()));
		System.out.println(new Date(file.lastModified()));
		
	
	}

}
