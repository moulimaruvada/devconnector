import java.awt.Desktop;
import java.io.File;
import java.io.IOException;

public class OpenFile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		File file = new File("sample1.txt");
		 if(!Desktop.isDesktopSupported()) {
			 System.out.println("desktop is not supported");
		 }
		 
		 Desktop desktop = Desktop.getDesktop();
		 if (file.exists()) {
			 try {
				desktop.open(file);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 	
		}
		 else {
			 System.out.println("file is not available");
		 }

	}

}
