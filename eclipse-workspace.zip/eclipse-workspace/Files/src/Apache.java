import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;

public class Apache {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File source = new File("C:\\Users\\Mouli\\eclipse-workspace\\Files\\tmp\\sample\\test\\sample.txt");
		File destination = new File("C:\\Users\\Mouli\\eclipse-workspace\\Files\\new\\new2\\new3\\sample1.txt");
		
		long start = System.nanoTime();
        try {
			FileUtils.copyFile(source, destination);
		} catch (IOException e) {
			// TODO Auto-generated catch block	
			e.printStackTrace();
		}
        System.out.println("Time taken by Apache Commons IO Copy = "+(System.nanoTime()-start));
//		try {
//			FileUtils.copyFile(source, destination);
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}

	}

}
