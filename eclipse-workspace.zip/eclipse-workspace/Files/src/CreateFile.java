import java.io.File;
import java.io.IOException;

public class CreateFile {
	
	public static void main(String[] args) {
		String fileSeparator = System.getProperty("file.separator");
		System.out.println(fileSeparator);
		
		
		//we have to provide the path
		
		
		
//		String absoluteFilePath = "E:\\Java File\\"+"sample.txt";
		String relativeFilePath = "tmp"+fileSeparator+"sample.txt";
		
		
		File file = new File(relativeFilePath);
//		File file = new File(absoluteFilePath);
		
//      if(file.createNewFile()) {
		if(file.delete()) {
			System.out.println("File Created");
			System.out.println(file);
		}
		else {
//				System.out.println("file already exists over"+absoluteFilePath);
			System.out.println("file already exists over"+relativeFilePath);
		}
	}

}
