import java.io.File;
import java.io.IOException;

public class Canonical {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String fileName = "./tmp/sample/test/sample.txt";
		File file = new File(fileName);
		
		try {
			
			System.out.println(file.getCanonicalPath());
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		

	}

}
