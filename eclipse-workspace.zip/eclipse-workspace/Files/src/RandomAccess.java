import java.io.IOException;
import java.io.RandomAccessFile;

public class RandomAccess {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		randomAccessFile();
		
	}
	
	public static void randomAccessFile() {

		try {
			RandomAccessFile randomAccessFile = new RandomAccessFile("sample1.txt","rw");
			randomAccessFile.writeInt(1234);
			randomAccessFile.seek(0);
			int number = randomAccessFile.readInt();
			System.out.println(number);
			
			System.out.println("hello");
			randomAccessFile.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 	

		
		
	}

}
