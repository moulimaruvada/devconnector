import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class Copy {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		File file = new File("WinDev2011Eval.ova");
		System.out.println(file.exists());
		System.out.println(file.length()/(1024*1024*1024));
		
		InputStream inputStream = null;
		OutputStream outputStream = null;
		long start = 0;
		long end = 0;
		
		try {
			inputStream = new FileInputStream(file);
			outputStream = new FileOutputStream("");
			byte[] buffer = new byte[1024*1024*1024*100];
			int length;
			start = System.nanoTime();
			System.out.println(start);
			while((length=inputStream.read(buffer))>0) {
				System.out.println("inside the");
				outputStream.write(buffer);
			}
			end = System.nanoTime();
			System.out.println("total time to copy" + (end-start));
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			
		}
	}

}
