import java.io.File;

public class Size {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String fileName = "tmp/sample/test/sample.txt";
		
		File file = new File(fileName);
		System.out.println((double)(file.length())+"bytes");
		System.out.println((double)(file.length()/(1024))+"kilobytes");
		System.out.println((double)(file.length()/(1024*1024))+"megsbytes");
	
	}
}
