import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class CsvScanner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			BufferedReader reader = new BufferedReader(new FileReader("data.csv"));
			
			String line= null;
			Scanner scanner = null;
			
			List<Employee1> employees = new ArrayList<Employee1>();
			int index = 0;
			while ((line = reader.readLine())!=null) {
				
				Employee1 employee = new Employee1();
				scanner = new Scanner(line);
				scanner.useDelimiter(",");
				while(scanner.hasNext()) {
					String data = scanner.next();
					System.out.println(data);
					if(index==0) {
						employee.setId(Integer.parseInt(data));
					}
					else if(index==1) {
						employee.setName(data);
					}
					else if(index==2) {
						employee.setRole(data);
					}
					else if(index==3) {
						employee.setSalary(data);
					}
					else {
						System.out.println("invalid");
						
					}
					index++;
					
				}
				index=0;
				
				System.out.println(line);
					
			}
			reader.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
