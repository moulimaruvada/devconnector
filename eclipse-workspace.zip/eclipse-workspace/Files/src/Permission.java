import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.attribute.PosixFilePermission;
import java.util.HashSet;
import java.util.Set;

public class Permission {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		String fileName = "sample.txt";
		File file = new File(fileName);
		
		

		
		try {
			
			Set<PosixFilePermission> filePermissions = new HashSet<PosixFilePermission>();
			
			filePermissions.add(PosixFilePermission.OWNER_READ);
			filePermissions.add(PosixFilePermission.OWNER_WRITE);
			
			Files.setPosixFilePermissions(Paths.get(fileName), filePermissions);
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
//		file.setReadable(false,false);
//		file.setReadOnly();
		

				

	

	}
}
