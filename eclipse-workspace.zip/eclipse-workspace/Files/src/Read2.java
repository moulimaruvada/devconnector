import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Read2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			BufferedReader bufferedReader = new BufferedReader(new FileReader(new File("tmp/sample/test/sample.txt")),50000);
			
			char[] line = new char[100];
			String ls = System.getProperty("line.separator");
			System.out.println("line separator "+ls.length());
			StringBuilder builder = new StringBuilder();
			long start = System.nanoTime();
			while(bufferedReader.read(line)!=-1) {
				
				builder.append(line);
//				builder.append(ls);
			}
			long end = System.nanoTime();
			System.out.println(builder);
			System.out.println(end-start);
			bufferedReader.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
