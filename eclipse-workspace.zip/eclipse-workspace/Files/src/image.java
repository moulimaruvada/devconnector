import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class image {

	public static void main(String[] args){
		
		try {
			byte[] fileData = Files.readAllBytes(Paths.get("20161224_224255-1.jpg"));
			 System.out.println(fileData);
			 
			 writeUsingFileWriter();
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       
	}
	
	public static void fileWriteBufferedWriter(String data) {
        File file = new File("fileWriter.txt");
        FileWriter fileWriter = null;
        
        try {
            fileWriter = new FileWriter(file,true);
            fileWriter.write(data);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        finally {
            try {
                fileWriter.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        
    }
	
public static void fileWriteDemo(byte[] data) {
        
        try {
            Files.write(Paths.get("20161224_224255-1.jpg"), data);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
        
    }
	

	
	public static void writeUsingFileWriter() {
			FileInputStream fileInputStream = null;
			FileOutputStream fileOutputStream = null;
		try {
			fileInputStream = new FileInputStream(new File("20161224_224255-1.jpg"));
			fileOutputStream = new FileOutputStream(new File("copied.jpg"));
			int ch;
			while((ch=fileInputStream.read())!=-1) {
				fileOutputStream.write(ch);
			}
				
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		finally {
			try {
				fileInputStream.close();
				fileOutputStream.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

}
