import java.io.File;

public class Rename {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String fileName = "tmp/sample/test/sample.txt";
		
		File file = new File(fileName);
		File file2 = new File("sample.txt");
		System.out.println(file.exists());
		boolean result = file.renameTo(file2);
		System.out.println(result);

	
	}

}
