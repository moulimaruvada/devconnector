import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class WriteFile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//1. FilesWrite
		
		try {
			String fileData = Files.readString(Paths.get("sample1.txt"));
			System.out.println(fileData);
			fileWriteDemo(fileData);
			writeUsingFileWriter(fileData);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}
	
	public static void fileWriteDemo(String data) {
		
		try {
			Files.write(Paths.get("files.txt"), data.getBytes());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
//	 	FileWriter
	public static void writeUsingFileWriter(String data) {
		File file = new File("fileWriter.txt");
		FileWriter fileWriter = null;
		try {
			fileWriter = new FileWriter(file);
			fileWriter.write(data);	
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			fileWriter.write(data);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	// Buffered Writer
	
	public static void fileWriteBufferedWriter(String data) {
		
		File file = new File("fileWriter.txt");
		FileWriter fileWriter = null;
		BufferedWriter bufferedWriter = null;
		String lineSeperator = System.getProperty("line.seperator");
		try {
			fileWriter = new FileWriter(file);
			bufferedWriter = new BufferedWriter(fileWriter);
			
			bufferedWriter.write(data+lineSeperator);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			fileWriter.close();
			bufferedWriter.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	

}
