package com.tavant;

//import java.text.DecimalFormat;
//
public class New {

	public static void main(String[] args) {
////		// TODO Auto-generated method stub
////		DecimalFormat df = new DecimalFormat("#,000.0#"); 
////		double pi = 3.141592653; 
////		System.out.println(df.format(pi));
////		
//
//			 int amount = 1_2_;
//			 System.out.println(amount); }
//	
//
//}

//import java.util.Locale;
//import java.text.DecimalFormat;
//import java.text.NumberFormat; 
//public class New { 
//public static void main(String [] args) { 
////NumberFormat nf = NumberFormat.getInstance(Locale.FRANCE); 
////String value = "444,33"; 
////System.out.println(nf.parse(value)); 
//Locale.setDefault(Locale.GERMANY); 
//DecimalFormat df = new DecimalFormat("#00.00##"); 
//double pi = 3.141592653; 
//System.out.println(df.format(pi));
//} 


//public class New {
// public static void main(String[] args) {
	
//	 int x = 10; 
//	 switch(x % 4.) {
//	 default: System.out.print("Not divisible by 4");
//	 case 0: System.out.print("Divisible by 4"); 
//	 }
	 
	 final char a = 'A', d = 'D';  char grade = 'B'; 
	 switch(grade) { 
	 case a: 
	 // p2 
	 case 'B': System.out.print("great"); 
	 case 'C': System.out.print("good"); 
	 break; 
	 case d:
	  // p3
	  case 'F': System.out.print("not good");
	  }
//int x = 10 % 2 + 1; 
//System.out.println(x);
//switch(x) { 
// case: 0 System.out.print("Too High"); break; 
// case: 1 System.out.print("Just Right"); break; 
// default: System.out.print("Too Low"); 
// }
}
}
