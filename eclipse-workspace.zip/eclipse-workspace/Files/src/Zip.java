import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class Zip {
	private static List<String> filesListInDir = new ArrayList<String>();
	public static void main(String[] args) {
       
        File dir = new File("./");
        String zipDirName = "././tmp.zip";
        
//        zipSingleFile(file, zipFileName);
//        
//        ZipFiles zipFiles = new ZipFiles();
        zipDirectory(dir, zipDirName);
    }
	 private static void zipDirectory(File dir, String zipDirName) {
	        try {
	            populateFilesList(dir);
	            //now zip files one by one
	            //create ZipOutputStream to write to the zip file
	            FileOutputStream fos = new FileOutputStream(zipDirName);
	            ZipOutputStream zos = new ZipOutputStream(fos);
	            for(String filePath : filesListInDir){
	                System.out.println("Zipping "+filePath);
	                //for ZipEntry we need to keep only relative file path, so we used substring on absolute path
	                ZipEntry ze = new ZipEntry(filePath.substring(dir.getAbsolutePath().length()+1, filePath.length()));
	                zos.putNextEntry(ze);
	                //read the file and write to ZipOutputStream
	                FileInputStream fis = new FileInputStream(filePath);
	                byte[] buffer = new byte[1024];
	                int len;
	                while ((len = fis.read(buffer)) > 0) {
	                    zos.write(buffer, 0, len);
	                }
	                zos.closeEntry();
	                fis.close();
	            }
	            zos.close();
	            fos.close();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	    
	    /**
	     * This method populates all the files in a directory to a List
	     * @param dir
	     * @throws IOException
	     */
	    private static void populateFilesList(File dir) throws IOException {
	        File[] files = dir.listFiles();
	        for(File file : files){
	            if(file.isFile()) filesListInDir.add(file.getAbsolutePath());
	            else populateFilesList(file);
	        }
	    }


	public static void zip() {
		String zipFileName= "././test.zip";

		String folder= "./";

		try {
			Path  zipFile = Files.createFile(Paths.get(zipFileName));
			Path sourceDir= Paths.get(folder);
			try(ZipOutputStream zipOutputStream = new ZipOutputStream(Files.newOutputStream(zipFile))) {
				
				Stream<Path> paths = Files.walk(sourceDir);
				
		            paths
		                    .filter(path -> !Files.isDirectory(path))
		                    .forEach(path -> {
		                        ZipEntry zipEntry = new ZipEntry(sourceDir.relativize(path).toString());
		                        try {
		                            zipOutputStream.putNextEntry(zipEntry);
		                            Files.copy(path, zipOutputStream);
		                            zipOutputStream.closeEntry();
		                        } catch (IOException e) {
		                            System.err.println(e);
		                        }
		                    });
				
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

			}
			

	
	
}
