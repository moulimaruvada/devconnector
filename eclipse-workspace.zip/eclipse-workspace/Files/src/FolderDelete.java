import java.io.File;

public class FolderDelete {

	public static void main(String[] args) {
		
		String folder = "new";
		
		File file = new File(folder);
		System.out.println(file.isDirectory());
		
		if(file.isDirectory()) {
			for(File f: file.listFiles()) {
				if(f.isDirectory()) {
					for(File f2: f.listFiles())
					{
						if(f2.isFile())
						{
							f2.delete();
						}
						else
						{
							for(File f3: f2.listFiles())
							{
								if(f3.isFile())
								{
									f3.delete();
								}
							}
						}
						
						System.out.println(f2);
					}
					System.out.println(f);
				}
			}
		}
	}
}
