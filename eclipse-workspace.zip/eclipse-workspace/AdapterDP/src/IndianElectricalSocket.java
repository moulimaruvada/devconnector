
public class IndianElectricalSocket {

	public void plugIn(IndianPlugConnector plug) {
		
		plug.provideElectricity();
		
	}
}
