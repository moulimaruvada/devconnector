
public class GermanToIndianPlugConnectorAdapter implements IndianPlugConnector {

	GermanPlugConnector germanPlugConnector;
	@Override
	public void provideElectricity() {
		
		this.germanPlugConnector.giveElectricity();

	}



	public GermanToIndianPlugConnectorAdapter(GermanPlugConnector connector) {
		this.germanPlugConnector = connector;
		}

}