
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GermanPlugConnector connector = () -> {
			System.out.println("German Plug connected");
		};
		
		
		GermanToIndianPlugConnectorAdapter adapter = new GermanToIndianPlugConnectorAdapter(connector);
		GermanElectricalSocket electricalSocket = new GermanElectricalSocket();
		electricalSocket.plugIn(connector);
	}

}
