
public interface IndianPlugConnector {

	public void provideElectricity();
}
