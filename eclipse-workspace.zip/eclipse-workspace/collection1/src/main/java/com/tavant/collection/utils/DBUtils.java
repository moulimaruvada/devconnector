package com.tavant.collection.utils;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import javax.sql.DataSource;

import org.apache.commons.dbcp2.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.mysql.cj.jdbc.MysqlDataSource;

@Component
@PropertySource("classpath:application.properties")
public class DBUtils {

//	@Autowired	
//	private FileUtils fileUtils;
	
	@Autowired
	Environment environment;
//	private static DBUtils dbUtils;
//
//	private DBUtils() {
//
//	}
//
//	public static DBUtils getInstance() {
//
//		if (dbUtils == null) {
//			synchronized (DBUtils.class) {
//				if (dbUtils == null) {
//					dbUtils = new DBUtils();
//				}
//			}
//		}
//
//		return dbUtils;
//	}
	
	public DataSource getDataSource() {
		//this 

		
		try {
//			Properties properties = fileUtils.readProperties();
			BasicDataSource datasource = new BasicDataSource();
			System.out.println("env class name"+environment.getClass().getName());
			datasource.setUrl(environment.getProperty("db.url"));
//		datasource.setServerName(properties.getProperty("db.serverName"));
//		datasource.setPortNumber(Integer.parseInt(properties.getProperty("db.port")));
//		datasource.setDatabaseName(properties.getProperty("db.name"));
			datasource.setUsername(environment.getProperty("db.username"));
			datasource.setPassword(environment.getProperty("db.password"));
//		datasource.setUrl(properties.getProperty("db.url"));
			return datasource;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
//		Certificate Options:
//			No ( sslMode=DISABLED )
//			Use to make a general connection without SSL.
//			If available, default value ( sslMode=PREFERRED )
//			Automatically attempt SSL connection. If the MySQL server does not support SSL, continue with a regular connection.
//			Require ( sslMode=REQUIRED )
//			Always connect with SSL. If the MySQL server doesn�t support SSL, the connection will not be established. Certificate Authority (CA) and Hostname are not verified.
//			Require and Verify CA ( sslMode=VERIFY_CA )
//			Always connect with SSL. Verifies CA, but allows connection even if Hostname does not match.
//			Require and Verify Identity ( sslMode=VERIFY_IDENTITY )
//			Always connect with SSL. Verify both CA and Hostname.
		
		

		
		//we worked with an application.properties file ==>
		//those details we will use to create data source
		//which is used to provide db details to your jdbc
	}
	
	public Connection getConnection() {
		// we need to load the driver 
		// DriverManager to get the connection object
		//using datasource approach
		Connection connection = null;
		try {
			connection = this.getDataSource().getConnection();
			return connection;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		//to get the db connection for performing the operations
	}
	
	public void closeConnection(Connection connection) {
	
		//used to close the jdbc connection
		try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}