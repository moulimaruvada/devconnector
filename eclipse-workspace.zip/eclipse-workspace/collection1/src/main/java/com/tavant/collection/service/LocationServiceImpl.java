package com.tavant.collection.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.tavant.collection.dao.LocationDAO;
import com.tavant.collection.dao.LocationDAOImpl;
import com.tavant.collection.model.Location;

@Service
public class LocationServiceImpl implements LocationService {

	LocationDAO locationDAO = new LocationDAOImpl(); 
	
	
	@Override
	public String addLocation(Location location) {
		// TODO Auto-generated method stub
		return locationDAO.addLocation(location);
	}

	@Override
	public Location updateLocation(String locId, Location location) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteLocation(String locId) {
		// TODO Auto-generated method stub
		return locationDAO.deleteLocation(locId);
	}

	@Override
	public Location getLocationById(String locId) {
		// TODO Auto-generated method stub
		return locationDAO.getLocationById(locId);
	}

	@Override
	public List<Location> getLocations() {
		// TODO Auto-generated method stub
		return locationDAO.getLocations();
	}

	@Override
	public boolean locationExistsById(String locId) {
		// TODO Auto-generated method stub
		return locationDAO.locationExistsById(locId) ;
	}

}
