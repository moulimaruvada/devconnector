package com.tavant.collection;

import java.sql.Connection;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import javax.sql.DataSource;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.tavant.collection.config.DBConfig;
import com.tavant.collection.model.Employee;
import com.tavant.collection.service.EmployeeService;
import com.tavant.collection.service.EmployeeServiceImpl;
import com.tavant.collection.utils.DBUtils;
import com.tavant.collection.utils.FileUtils;

public class Main {

	//internally inside the spring some one will maintain the objects(rt from begging till destroying object)
	//1. ApplicationContext: commonly used application context is a  
	//wrapper applied on the BeanFactory container.
	//
	//2. Beanfactory
	
	
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(DBConfig.class);
		
		Arrays.asList(context.getBeanDefinitionNames()).forEach(System.out::println);	
		DBUtils dbUtils = context.getBean(DBUtils.class);
		System.out.println(dbUtils!=null);
		DBUtils dbUtils1 = context.getBean(DBUtils.class);
		
		DataSource datasource = dbUtils.getDataSource();
		System.out.println("before data source"+(datasource != null));
		

		
		System.out.println(dbUtils1!=null);
//		System.out.println(dbUtils.hashCode());
//		System.out.println(dbUtils1.hashCode());
//		System.out.println(dbUtils.equals(dbUtils1));
//		System.out.println(context.getBean("employeeService")!=null);
		EmployeeService employeeService = context.getBean("employeeService", EmployeeService.class);
//		Employee employee = new Employee(2331,"Ash","Ketchem","aa12","ash@gmail.com","4",1002,"Trainer");
		
//		String res = employeeService.addEmployee(employee);
//		System.out.println("insert result"+res);
		employeeService.employeeExistsById("2331");
//		Optional<Employee> result = employeeService.getEmployeeById("1710");
//		Optional<List<Employee>> result1 = employeeService.getEmployees();
//		if(result1.isPresent())
//		{
//			result1.get().forEach(System.out::println);
//		}
//		else
//		{
//			System.out.println("No results found");
//		}
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		EmployeeService employeeService = EmployeeServiceImpl.getInstance();
//		Optional<List<Employee>> optional = employeeService.getEmployees();
////	    employeeService.getEmployeeById("1076");
////		employeeService.employeeExistsById("1102");
////		if(optional.isPresent()) {
////			optional.get().forEach(System.out::println);
////		}
////		else
////		{
////			System.out.println("There is no record");
////		}
//		
//		                 //add
////		Employee employee = new Employee(1707,"Peter","Parker","Spidey","Pete@gmail.com","4",1002,"Sales Rep");
////		String add = employeeService.addEmployee(employee);
////		System.out.println(add);
//		
//		               //delete
////		String del = employeeService.deleteEmployee("1706");
////		System.out.println(del);
//		
//					  //Exists
////		employeeService.employeeExistsById("1705");
//		
//					 //Update
//		Employee employee = new Employee(1710,"Mouli","Maruvada","M","m@gmail.com","4",1002,"Sales Rep");
//		employeeService.updateEmployee("1709", employee);
//		
//
//	}
//
//	
//	
}
