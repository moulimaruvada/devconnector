package com.tavant.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Lazy;

@Import(DBConfig.class)
@Configuration
@ComponentScan("com.tavant.demo")
public class Config {

	
	@Bean("emp1")
	@Lazy(false)
	public Employee getEmployeeObject() {
		System.out.println("hello from empobject ");
		return new Employee();
	}
	
	@Bean
	public Company getCompanyObject()
	{
		return new Company();
	}
}
