package com.tavant.demo;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("prototype")
public class Company {
	
		private Employee employee;
		
		
		@Autowired
		public Company(Employee employee) {
			// TODO Auto-generated constructor stub
			this.employee=employee;
			
		}

		
		public Company() {
			System.out.println("From company constructor");
			// TODO Auto-generated constructor stub
		}
		
		@PostConstruct
		public void init() {
			System.out.println("From init");
		}
		
		@PreDestroy
		public void destroy() {
			System.out.println("From destroy");
		}

}
