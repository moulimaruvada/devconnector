package com.tavant.demo;




import java.util.Arrays;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(Config.class);
//		Company company = context.getBean(Company.class);
//		System.out.println(company.hashCode());
//		
//		Company company1 = context.getBean(Company.class);
//		System.out.println(company1.hashCode());
		
//		Arrays.asList(context.getBeanDefinitionNames()).forEach(System.out::println);
		
//		Employee employee = context.getBean("emp2",Employee.class);
//		System.out.println(employee);
		context.close();
	}

}
