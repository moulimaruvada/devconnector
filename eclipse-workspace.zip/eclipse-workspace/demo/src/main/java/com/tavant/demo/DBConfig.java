package com.tavant.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;



@Component
public class DBConfig {
	
	@Bean("emp2")
	@Lazy(false)
	public Employee getEmployeeObject2() 
	{
		System.out.println("hello from emp2");
		return new Employee();
	}

}
