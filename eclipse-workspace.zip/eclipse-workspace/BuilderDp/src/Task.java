import java.util.Date;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data


public class Task {

	
	private final long Id;
	private String 	summary;
	private String description;
	private boolean status;
	private Date dueDate;
	
public Task() {
this.Id=0;
}

public Task(long id, String summary, String description, boolean status, Date dueDate) {
	super();
	this.Id = id;
	this.summary = summary;
	this.description = description;
	this.status = status;
	this.dueDate = dueDate;
}
	
}

