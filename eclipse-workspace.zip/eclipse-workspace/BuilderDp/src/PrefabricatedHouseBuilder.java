
public class PrefabricatedHouseBuilder implements HouseBuilder {

	
	private House house;
	
	public PrefabricatedHouseBuilder() {
		// TODO Auto-generated constructor stub
		house = new House();
	}
	
	@Override
	public void buildFoundation() {
		// TODO Auto-generated method stub
		house.setFoundation("Wood, Laminated, and PVC Flooring");
		System.out.println("PrefabricatedHouseBuilder : Foundation Complete");
		
	}

	@Override
	public void buildStructure() {
		// TODO Auto-generated method stub
		house.setStructure("Structural Steel wooden panels");
		System.out.println("PrefabricatedHouseBuilder : Structure Complete");

	}

	@Override
	public void buildRoof() {
		// TODO Auto-generated method stub
		house.setRoof("Roof putty and Coating");
		System.out.println("PrefabricatedHouseBuilder : Roof Complete");

	}

	@Override
	public void paintHouse() {
		// TODO Auto-generated method stub
		house.setPainting("Wall Painting");
		System.out.println("PrefabricatedHouseBuilder : Painting Complete");
	}

	@Override
	public void furnitureHouse() {
		// TODO Auto-generated method stub
		house.setFurniture("Cupboard ");
		System.out.println("PrefabricatedHouseBuilder : Furniture Complete");
	}

	@Override
	public House getHouse() {
		// TODO Auto-generated method stub
		return house;


	}

}
