
public class PrefabricatedEngineer {

	private HouseBuilder builder;
	
	public PrefabricatedEngineer(HouseBuilder houseBuilder) {
		this.builder = houseBuilder;
	}

	
	public House constructHouse() {
		this.builder.buildFoundation();
		this.builder.buildStructure();
		this.builder.buildRoof();
		this.builder.getHouse();
		return this.builder.getHouse();
	}
}
