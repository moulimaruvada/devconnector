import java.util.Date;

public class TaskBuilder {

	private final long id;
	private String summary;
	private String description;
	private boolean status;
	private Date dueDate;
	public TaskBuilder(long id) {
		super();
		this.id = id;
		this.setDescription("").setDueDate(null);
		new StringBuilder("hello").append("abhi").toString();
	}
	
	public TaskBuilder setSummary(String summary) {
		this.summary = summary;
		return this;
	}
	public TaskBuilder setDescription(String description) {
		this.description = description;
		return this;
		
	}
	public TaskBuilder setStatus(boolean status) {
		this.status = status;
		return this;
		
	}
	public TaskBuilder setDueDate(Date dueDate) {
		this.dueDate = dueDate;
		return this;
		
	}
	public Task build() {
		return new Task(id,summary,description,status,dueDate);
		
	}
	
}
