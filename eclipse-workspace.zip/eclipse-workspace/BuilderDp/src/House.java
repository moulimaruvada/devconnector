import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class House {



	private String foundation;
	private String Structure;
	private String roof;
	private String furniture;
	private String painting;
}
