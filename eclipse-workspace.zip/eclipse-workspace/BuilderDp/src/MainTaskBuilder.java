import java.util.Date;

public class MainTaskBuilder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TaskBuilder builder = new TaskBuilder(100);
			
		Task task = builder.setDescription("Hello")
				.setSummary("nothing")
				.setDueDate(new Date())
				.build();
		System.out.println(task);
	}

}
