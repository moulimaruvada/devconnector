package com.tavant.collection;

import java.util.List;

import com.tavant.collection.service.DepartmentService;
import com.tavant.collection.service.DepartmentServiceImpl;
import com.tavant.collection.service.EmployeeService;
import com.tavant.collection.service.EmployeeServiceImpl;
import com.tavant.collection.service.LocationService;
import com.tavant.collection.service.LocationServiceImpl;

public class ServiceFactory {
	
	public static Object getService(List<String> serviceTypes, boolean lazy) {
	
		if(lazy) {
			
			for(String servicetype:serviceTypes)
			{
				if("employeeserviceImpl".equalsIgnoreCase(servicetype)) {
					EmployeeService employeeService = EmployeeServiceImpl.getInstance();
				}
				if("departmentServiceImpl".equalsIgnoreCase(servicetype)) {
					DepartmentService departmentService = DepartmentServiceImpl.getInstance();
				}
				if("locationServiceImpl".equalsIgnoreCase(servicetype)) {
					LocationService locationService = LocationServiceImpl.getInstance();
				}
				
			}
		}
		else {
			EmployeeService employeeService = EmployeeServiceImpl.getInstance();
			DepartmentService departmentService = DepartmentServiceImpl.getInstance();
			LocationService locationService = LocationServiceImpl.getInstance();
			
		}
		
		return lazy;
		
	}

}
