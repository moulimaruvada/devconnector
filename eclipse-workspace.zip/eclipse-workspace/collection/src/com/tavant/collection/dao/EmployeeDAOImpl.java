	package com.tavant.collection.dao;
import java.util.Comparator;
import java.util.ArrayList;
//import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.tavant.collection.model.Employee;
import com.tavant.collection.service.DepartmentService;
import com.tavant.collection.service.DepartmentServiceImpl;

public class EmployeeDAOImpl implements EmployeeDAO {

	private Set<Employee> employees = new TreeSet<Employee>(new Comparator<Employee>() {
		@Override
		public int compare(Employee emp1, Employee emp2) {
			return emp1.getEmpId().compareTo(emp2.getEmpId());
		}
	});
	
	private Set<Employee> employees1 = new TreeSet<Employee>((e1,e2)->{return e1.getEmpId().compareTo(e2.getEmpId());});
	
	private Set<Employee> employees2 = new TreeSet<Employee>((e1,e2)->e1.getEmpId().compareTo(e2.getEmpId()));
	
	
	private static EmployeeDAO employeeDAOImpl;
	
	public static EmployeeDAO getInstance() {
		
		if(employeeDAOImpl==null) {
			employeeDAOImpl = new EmployeeDAOImpl(); 
		}
		return employeeDAOImpl;
	}
	
	
	// DC ===> 10
	// parameterized ===> size
	// prameterzed another ===> will accept Collection (used to transfrom any collection to list)
	
	@Override
	public String addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		boolean result = employees.add(employee);
		if(result) {
			return "Success";
		}
		else {
			return "Fail";	
		}
		
		
	}

	@Override
	public Optional<Employee> updateEmployee(String empId, Employee employee) {
		// TODO Auto-generated method stub
		return Optional.empty();
	}

	@Override
	public String deleteEmployee(String empId) {
		// TODO Auto-generated method stub
		
		
		try {
			employees = employees.stream().filter(e->!(e.getEmpId().equals(empId)))
					.collect(Collectors.toSet());
		return "success";
		
		} catch (Exception e) {
		
			e.printStackTrace();
		
			return "fail";
			
		}
		
		
//		int index = 1;
//	Iterator<Employee> iterator = employees.iterator();
//	while(iterator.hasNext()) {
//			Employee employee = (Employee) iterator.next();
//			index++;
//			if(empId.equals(employee.getEmpId())) {
//				break;
//			}
//		}
//		employees.remove(index);
	}

	@Override
	public Optional<Employee> getEmployeeById(String empId) {
		// TODO Auto-generated method stub
		
		Stream<Employee> stream = employees.stream();
		
	    stream.filter(e->e.getEmpId().equals(empId))
	    .forEach(System.out::println);
		return null;
		
		
//		for(Employee employee : employees) {
//			if(employee.getEmpId().equals(empId))
//			{
//				return Optional.of(employee);
//			}
//		}
//
		
	}

	@Override
	public Optional<List<Employee>> getEmployees() {
		// TODO Auto-generated method stub
		if(employees.isEmpty()) {
			return Optional.empty();
		}
		return Optional.ofNullable(new ArrayList<Employee>(employees));
	}

	@Override
	public boolean employeeExistsById(String empId) {
		// TODO Auto-generated method stub
		
		return employees.contains(this.getEmployeeById(empId));
	}

}
