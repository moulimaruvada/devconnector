package com.tavant.collection.dao;

import java.util.ArrayList;
import java.util.List;


import com.tavant.collection.model.Location;

public class LocationDAOImpl implements LocationDAO {

	private List<Location> locations = new ArrayList<Location>();
	
	private static LocationDAO locationDAOImpl;
	
	public static LocationDAO getInstance() {
		
		if(locationDAOImpl==null)
		{
			locationDAOImpl= new LocationDAOImpl();
			return locationDAOImpl;
		}
		return locationDAOImpl;
	}
	
	
	
	@Override
	public String addLocation(Location location) {
		// TODO Auto-generated method stub
		boolean result = locations.add(location);
		if(result) {
			return "Success";
		}
		else {
			return "Fail";	
		}
		

	}

	@Override
	public Location updateLocation(String locId, Location location) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteLocation(String locId) {
		// TODO Auto-generated method stub
		
		boolean result = locations.remove(this.getLocationById(locId));
		if(result) return "Success";
		else return "Fail";

	}

	@Override
	public Location getLocationById(String locId) {
		// TODO Auto-generated method stub

		for(Location location : locations) {
			if(location.getLocId(locId).equals(locId))
			{
				return location;
			}
		}
		
		return null;
	}

	@Override
	public List<Location> getLocations() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean locationExistsById(String locId) {
		// TODO Auto-generated method stub
		return locations.contains(this.getLocationById(locId));
	}

}
