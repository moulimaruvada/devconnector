package com.tavant.collection;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map.Entry;
import java.util.TreeMap;

public class MapMain {
	
	public static void main(String[] args) {
		TreeMap<Integer, String> hashMap = new TreeMap<Integer, String>();
		
		//to add the data in map
		hashMap.put(10,"Mouli");
		hashMap.put(-2,"Maruvada");
		hashMap.put(1000,null);
		hashMap.put(111,"Maru");
		
//		System.out.println(hashMap.descendingMap());
//		System.out.println(hashMap.descendingKeySet());
//		System.out.println(hashMap.higherEntry(59));
//		System.out.println(hashMap.higherKey(68));
//		System.out.println(hashMap.lowerEntry(50));
		System.out.println(hashMap.lowerKey(50));
		
//		String data = linkedhashMap.get(10);
//		boolean b = linkedhashMap.containsKey(100);
//		System.out.println(b);
//		b = linkedhashMap.containsValue("mouli"); 
//		System.out.println(b);
//		
//		System.out.println(data);
		
		
		
//		hashMap.forEach((k,v)->{
//			System.out.println(k+"value"+v);
//		});
//		
//		
//		
//		for (Entry<Integer, String> string : hashMap.entrySet()) {
//			System.out.println(string.getKey()+"value"+string.getValue());
//		}
//		
//		System.out.println(hashMap);
	}

}
