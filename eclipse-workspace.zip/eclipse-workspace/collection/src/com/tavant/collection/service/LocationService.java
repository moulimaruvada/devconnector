package com.tavant.collection.service;

import java.util.List;

import com.tavant.collection.model.Location;

public interface LocationService {
	
	public String addLocation(Location location);
	public Location updateLocation(String locId, Location location);
	public String deleteLocation(String locId);
	public Location getLocationById(String locId);
	public List<Location> getLocations();
	
	public boolean locationExistsById(String locId);

}
