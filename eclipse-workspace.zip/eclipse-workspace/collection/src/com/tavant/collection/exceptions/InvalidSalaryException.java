package com.tavant.collection.exceptions;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public class InvalidSalaryException extends Exception {
	
public InvalidSalaryException(String msg) {
	super(msg);
	
}	

@Override	
	public String toString() {
	
		return super.toString()+ this.getMessage();
}


}
