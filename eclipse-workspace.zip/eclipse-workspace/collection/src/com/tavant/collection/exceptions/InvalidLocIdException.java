package com.tavant.collection.exceptions;

public class InvalidLocIdException extends Exception {
	
	public InvalidLocIdException(String msg) {
		super(msg);
		
	}	

	@Override	
		public String toString() {
		
			return super.toString()+ this.getMessage();
	}


}
