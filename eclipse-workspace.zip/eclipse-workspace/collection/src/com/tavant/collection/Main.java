package com.tavant.collection;

import java.util.Scanner;
import java.util.List;
import java.util.Optional;

import com.tavant.collection.exceptions.InvalidDepIdException;
import com.tavant.collection.exceptions.InvalidLocIdException;
import com.tavant.collection.exceptions.InvalidNameException;
import com.tavant.collection.exceptions.InvalidSalaryException;
import com.tavant.collection.model.Department;
import com.tavant.collection.model.Employee;
import com.tavant.collection.model.Location;
import com.tavant.collection.service.DepartmentService;
import com.tavant.collection.service.DepartmentServiceImpl;
import com.tavant.collection.service.EmployeeService;
import com.tavant.collection.service.EmployeeServiceImpl;
import com.tavant.collection.service.LocationService;
import com.tavant.collection.service.LocationServiceImpl;

public class Main {

	public static void main(String[] args) throws InvalidSalaryException, InvalidDepIdException, InvalidLocIdException, InvalidNameException {
		
		EmployeeService employeeService = new EmployeeServiceImpl();
		DepartmentService departmentService = new DepartmentServiceImpl();
		LocationService locationService = new LocationServiceImpl();
		
		Scanner s = new Scanner(System.in); 
		while(true)
		{
			
			System.out.println("Enter your choice");
			int choice = s.nextInt();
			
			switch(choice) {
				case 1:
					Employee employee = new Employee();
					employee.setEmpFirstName("Mouli");
					employee.setEmpLastName("Maruvada");
					employee.setEmpSalary(100);
					employee.setEmpId("AB01");
					String result = employeeService.addEmployee(employee);
					System.out.println("The Employee details are added " +result);
					
					Department department = new Department();
					department.setDepName("CSE");
					department.setDepId("CSEWE1");
					department.setDepLoc("2nd");
					String result1 = departmentService.addDepartment(department);
					System.out.println("The Department details are added " +result1);
					
					Location location = new Location();
					location.setLocName("Bangalore");
					location.setLocId("Bangalore1");
					String result2 = locationService.addLocation(location);
					System.out.println("The Location details are added " +result2);
					
					break;
				case 2:
					//Update
					
					break;
				case 3:
					String employees1 = employeeService.deleteEmployee("AB01");
					System.out.printf("The deletion is %s",employees1);
					
					String department1 = departmentService.deleteDepartment("CSEWE1");
					System.out.printf("The deletion is %s", department1);
					
					String location1 = locationService.deleteLocation("Bangalore1");
					System.out.printf("The deletion is %s", location1);
					
					break;
				case 4:
					//retrieval case
					Optional<Employee> employee2 = employeeService.getEmployeeById("AB01");
					System.out.println(employee2);
					Department department2 = departmentService.getDepartmentById("CSEWE1");
					System.out.println(department2);
					Location location2 = locationService.getLocationById("Bangalore1");
					System.out.println(location2);
					
					break;
				case 5:
					// retrieve all
					break;	
				case 6:
					//exists method call
					break;
				case 7:
					//exit
					System.exit(0);	
					
				default:
					break;
					
			}
		}
		
//		List<Employee> employees = employeeService.getEmployees();
//		
//		for (Employee employee2 : employees) {
//			System.out.println(employee2);
//		}
		
		
	}
}
