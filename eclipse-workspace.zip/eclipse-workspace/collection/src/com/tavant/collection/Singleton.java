package com.tavant.collection;

import com.tavant.collection.dao.DepartmentDAO;
import com.tavant.collection.dao.DepartmentDAOImpl;
import com.tavant.collection.dao.EmployeeDAO;
import com.tavant.collection.dao.EmployeeDAOImpl;
import com.tavant.collection.dao.LocationDAO;
import com.tavant.collection.dao.LocationDAOImpl;
import com.tavant.collection.service.DepartmentService;
import com.tavant.collection.service.DepartmentServiceImpl;
import com.tavant.collection.service.EmployeeService;
import com.tavant.collection.service.EmployeeServiceImpl;
import com.tavant.collection.service.LocationService;
import com.tavant.collection.service.LocationServiceImpl;

public class Singleton {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		EmployeeDAO emp = EmployeeDAOImpl.getInstance();
		
		System.out.println(emp.hashCode());
		EmployeeDAO emp1 = EmployeeDAOImpl.getInstance();
		System.out.println(emp1.hashCode());
		EmployeeDAO emp2 = EmployeeDAOImpl.getInstance();
		System.out.println(emp2.hashCode());
		EmployeeDAO emp3 = EmployeeDAOImpl.getInstance();
		System.out.println(emp3.hashCode());
		System.out.println(emp.equals(emp1));
		System.out.println(emp1.equals(emp2));
		System.out.println(emp2.equals(emp3));
		

		
		EmployeeService employ = EmployeeServiceImpl.getInstance();
		
		System.out.println(employ.hashCode());
		EmployeeService employ1 = EmployeeServiceImpl.getInstance();
		System.out.println(employ1.hashCode());
		EmployeeService employ2 = EmployeeServiceImpl.getInstance();
		System.out.println(employ2.hashCode());
		EmployeeService employ3 = EmployeeServiceImpl.getInstance();
		System.out.println(employ3.hashCode());
		System.out.println(employ.equals(employ1));
		System.out.println(employ1.equals(employ2));
		System.out.println(employ2.equals(employ3));
		
		
		
		DepartmentDAO dao = DepartmentDAOImpl.getInstance();
		
		System.out.println(dao.hashCode());
		DepartmentDAO dao2 = DepartmentDAOImpl.getInstance();
		System.out.println(dao2.hashCode());
		DepartmentDAO dao3 = DepartmentDAOImpl.getInstance();
		System.out.println(dao3.hashCode());
		DepartmentDAO dao4 = DepartmentDAOImpl.getInstance();
		System.out.println(dao4.hashCode());
		System.out.println(dao.equals(dao2));
		System.out.println(dao2.equals(dao3));
		System.out.println(dao3.equals(dao4));
		
		
		
		DepartmentService ser = DepartmentServiceImpl.getInstance();
		
		System.out.println(ser.hashCode());
		DepartmentService ser1 = DepartmentServiceImpl.getInstance();
		System.out.println(ser1.hashCode());
		DepartmentService ser2 = DepartmentServiceImpl.getInstance();
		System.out.println(ser2.hashCode());
		DepartmentService ser3 = DepartmentServiceImpl.getInstance();
		System.out.println(ser3.hashCode());
		System.out.println(ser.equals(ser1));
		System.out.println(ser1.equals(ser2));
		System.out.println(ser2.equals(ser3));
		
		
		
		LocationService loc = LocationServiceImpl.getInstance();	
		
		System.out.println(loc.hashCode());
		LocationService loc1 = LocationServiceImpl.getInstance();
		System.out.println(loc1.hashCode());
		LocationService loc2 = LocationServiceImpl.getInstance();
		System.out.println(loc2.hashCode());
		LocationService loc3 = LocationServiceImpl.getInstance();
		System.out.println(loc3.hashCode());
		System.out.println(loc.equals(loc1));
		System.out.println(loc1.equals(loc2));
		System.out.println(loc2.equals(loc3));
		
		
		LocationDAO locat = LocationDAOImpl.getInstance();
		
		System.out.println(locat.hashCode());
		LocationDAO locat1 = LocationDAOImpl.getInstance();
		System.out.println(locat1.hashCode());
		LocationDAO locat2 = LocationDAOImpl.getInstance();
		System.out.println(locat2.hashCode());
		LocationDAO locat3 = LocationDAOImpl.getInstance();
		System.out.println(locat3.hashCode());
		System.out.println(locat.equals(locat1));
		System.out.println(locat1.equals(locat2));
		System.out.println(locat2.equals(locat3));
		
		
	}

}
