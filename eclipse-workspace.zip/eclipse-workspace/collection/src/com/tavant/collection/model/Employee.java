package com.tavant.collection.model;

import com.tavant.collection.exceptions.InvalidSalaryException;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor


public class Employee implements Comparable<Employee> {
	
	public Employee(String empId, String empFirstName, String empLastName, float empSalary) throws InvalidSalaryException {
		super();
		this.empId = empId;
		this.empFirstName = empFirstName;
		this.empLastName = empLastName;
		this.setEmpSalary(empSalary);
	}
	
	
	private String empId;
	private String empFirstName;
	private String empLastName;
	private float empSalary;
	

	public void setEmpSalary(float empSalary) throws InvalidSalaryException{
		if(empSalary<0) {
			throw new InvalidSalaryException("Salary Should Not be Negative");
		}
		this.empSalary = empSalary;
	}
	
	
	public int compareTo(Employee arg0) {
	return arg0.getEmpId().compareTo(this.getEmpId());
	}
}

