package com.tavant.collection.model;

import com.tavant.collection.exceptions.InvalidDepIdException;
import com.tavant.collection.exceptions.InvalidNameException;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



public class Department {
	

	
	public String depId;
	public String depName;
	public String depLoc;
	
	public String getDepId(String depId)
	{
		return depId;
	}
	
	

	@Override
	public String toString() {
		return "Department [depId=" + depId + ", depName=" + depName + ", depLoc=" + depLoc + "]";
	}



	public void setDepLoc(String depLoc) {
		this.depLoc = depLoc;
	}

//	public String getDepId() {
//		return depId;
//	}

	public String getDepName() {
		return depName;
	}


	public String getDepLoc() {
		return depLoc;
	}
	
	public void setDepId(String DepId) throws InvalidDepIdException
	{
		
		if(DepId.length()<6)
		{
			throw new InvalidDepIdException("Enter a valid Department Id");
		}
		else
		{
			this.depId = DepId;
		}
	}
	
	public void setDepName(String DepName) throws InvalidNameException
	{
		if(DepName.length()>4)
		{
			throw new InvalidNameException("Enter a valid department name");
		}
		else
		{
			this.depName = DepName;
		}
	}

}
