
public class AnimalFactory {

	public Animal getAnimal(String animalName) {
		// TODO Auto-generated method stub
		if("Dog".equalsIgnoreCase(animalName))
		{
			return new Dog();
		}
		else if("Cat".equalsIgnoreCase(animalName))
		{
			return new Cat();
		}
		else if("Rabbit".equalsIgnoreCase(animalName))
		{
			return new Rabbit();
		}
		return null;
	}
	

	public Object getObject(String objectType, boolean flag) {
		
		if("employeeService".equalsIgnoreCase(objectType)) {
			// create an employeeService object
		}
		else if("employeeDAO".equalsIgnoreCase(objectType))
		{
			// create an employeeDAO object
		}
		// for other cases
		
		// here i m providing a flag called lazy = true then it will provide the objects on demand
		// if lazy = false (eargly )==> it should create all dao service objects @ the time of
		// starting the application
		// on the basis of layz value if lazy is true ===> on demand 
		// lazy = false ===> we should create all the object well in adv.
		
		// this thing is implemented by using factory in spring.
		
		return null;
	}

}
