
public class MainFactory {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Animal animal = new AnimalFactory().getAnimal("dog");
		System.out.println(animal instanceof Dog);
		Animal animal2 = new AnimalFactory().getAnimal("Cat");
		System.out.println(animal2 instanceof Cat);
		Animal animal3 = new AnimalFactory().getAnimal("Rabbit");
		System.out.println(animal3 instanceof Rabbit);

	}

}
