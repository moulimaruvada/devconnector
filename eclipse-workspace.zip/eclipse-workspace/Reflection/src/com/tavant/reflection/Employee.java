package com.tavant.reflection;

public class Employee  {
	
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
		System.out.println("Hello this i empId");
	}
	public String getEmpFirstName() {
		return empFirstName;
	}
	public void setEmpFirstName(String empFirstName) {
		this.empFirstName = empFirstName;
		System.out.println("Hello this i empFirstName");
	}
	public String getEmpLastName() {
		return empLastName;
	}
	public void setEmpLastName(String empLastName) {
		this.empLastName = empLastName;
		System.out.println("Hello this i empLastName");
	}
	public float getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(float empSalary) {
		this.empSalary = empSalary;
		System.out.println("Hello this i empSalary");
	}
	private String empId;
	private String empFirstName;
	private String empLastName;
	private float empSalary;
	


}

