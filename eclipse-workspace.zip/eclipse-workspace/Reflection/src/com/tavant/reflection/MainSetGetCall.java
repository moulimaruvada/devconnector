package com.tavant.reflection;

import java.lang.reflect.Field;

public class MainSetGetCall {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Field field = Class.forName(ConcreteClass.class.getName()).getField("PublicInt");
			Class<?> fieldType = field.getType();
			System.out.println(fieldType.getCanonicalName());
			System.out.println(field.getName());
			ConcreteClass obj = new ConcreteClass(5);
			System.out.println(field.get(obj));// to retrieve the publicInt value.
			field.setInt(obj, 2000);
			System.out.println(field.get(obj));// to retrieve the publicInt value.
		} catch (NoSuchFieldException | SecurityException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
