package com.tavant.reflection;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Scanner;

public class MainCallSetterGetter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee employee = new Employee();
//		employee.setEmpFirstName("mouli");
//		System.out.println(employee.getEmpFirstName());
		Field[] field = Employee.class.getDeclaredFields();
//		for(Field f : field) {
//			System.out.println(f.getType());
//			System.out.println(f.getName());
//		}
//		invokeSetter(employee, "empId", "A001");
//		invokeGetter(employee, "empId");
//		invokeSetter(employee, "empFirstName", "Mouli");
//		invokeGetter(employee, "empFirstName");
//		invokeSetter(employee, "empLastName", "Maruvada");
//		invokeGetter(employee, "empLastName");
//		invokeSetter(employee, "empSalary", 100.0f);
//		invokeGetter(employee, "empSalary");
		
		for(Field f: field) {
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter the "+f.getName());
			if(f.getType().getName().equals("float"))
			{
				invokeSetter(employee,f.getName(),sc.nextFloat());
			}
			else 
			{
				invokeSetter(employee,f.getName(),sc.next());
			}
		}
		for(Field f:field)
		{
			invokeGetter(employee,f.getName());
		}
	}
	
	public static void invokeSetter(Object object,String propertyName, Object value) {
		

		try {
			PropertyDescriptor propertyDescriptor;
			Method method;
			propertyDescriptor = new PropertyDescriptor(propertyName, object.getClass());
			method = propertyDescriptor.getWriteMethod();
			method.invoke(object, value);
		} catch (IntrospectionException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void invokeGetter(Object object,String propertyName) {
		
		try {
			PropertyDescriptor propertyDescriptor;
			Method method;
			propertyDescriptor = new PropertyDescriptor(propertyName, object.getClass());
			method = propertyDescriptor.getReadMethod();
			Object result = method.invoke(object);
			System.out.println(result);
		} catch (IntrospectionException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	

	
	
	
}
