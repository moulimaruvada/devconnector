package com.tavant.springboot.dao;

import java.util.List;
import java.util.Optional;

import com.tavant.springboot.model.Office;

public interface OfficeDAO {

	public String addOffice(Office office);
	public Optional<Office> updateOffice(String offId,Office office);
	public String deleteOffice(String offId);
	public Optional<Office> getOfficeById(String offId);
	public Optional<List<Office>> getOffices();
	
	public boolean officeExistsById(String offId);
	
}
