package com.tavant.springboot.service;

import java.util.List;
import java.util.Optional;

import com.tavant.springboot.model.Product;

public interface ProductService {

	
	public String addProduct(Product product);
	public Optional<Product> updateProduct(String prodId,Product product);
	public String deleteProduct(String prodId);
	public Optional<Product> getProductById(String prodId);
	public Optional<List<Product>> getProducts();
	
	public boolean productExistsById(String prodId);
}
