package com.tavant.springboot.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class Payment {

	private int customerNumber;
	private String checkNumber;
	private String paymentDate;
	private float amount;
}
