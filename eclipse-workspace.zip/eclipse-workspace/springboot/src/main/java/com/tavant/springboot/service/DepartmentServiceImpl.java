package com.tavant.springboot.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.tavant.springboot.dao.DepartmentDAO;
import com.tavant.springboot.dao.DepartmentDAOImpl;
import com.tavant.springboot.model.Department;

@Service
public class DepartmentServiceImpl implements DepartmentService {

	DepartmentDAO departmentDAO = new DepartmentDAOImpl();
	
	
	
	@Override
	public String addDepartment(Department department) {
		// TODO Auto-generated method stub
		return departmentDAO.addDepartment(department);
	}

	@Override
	public Department updateDepartment(String depId, Department department) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteDepartment(String depId) {
		// TODO Auto-generated method stub
		return departmentDAO.deleteDepartment(depId);
	}

	@Override
	public Department getDepartmentById(String depId) {
		// TODO Auto-generated method stub
		return departmentDAO.getDepartmentById(depId);
	}

	@Override
	public List<Department> getDepartments() {
		// TODO Auto-generated method stub
		return departmentDAO.getDepartments();
	}

	@Override
	public boolean departmentExistsById(String depId) {
		// TODO Auto-generated method stub
		return departmentDAO.departmentExistsById(depId) ;
	}

}
