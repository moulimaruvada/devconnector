package com.tavant.springboot.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
//import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tavant.springboot.model.Employee;
import com.tavant.springboot.utils.DBUtils;

@Repository
public class EmployeeDAOImpl implements EmployeeDAO {

	@Autowired
	DBUtils dbUtils;

	
	
	@Override
	public String addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		String insertStatement = "insert into employees (firstName,lastName,extension,jobTitle,email,officeCode,reportsTo,employeeNumber) values(?,?,?,?,?,?,?,?)";
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		connection = dbUtils.getConnection();
		try {
			preparedStatement = connection.prepareStatement(insertStatement);
			preparedStatement.setString(1, employee.getFirstName());
			preparedStatement.setString(2, employee.getLastName());
			preparedStatement.setString(3, employee.getExtension());
			preparedStatement.setString(4, employee.getJobTitle());
			preparedStatement.setString(5, employee.getEmail());
			preparedStatement.setString(6, employee.getOfficeCode());
			preparedStatement.setInt(7, employee.getReportsTo());
			preparedStatement.setInt(8, employee.getEmployeeNumber());
			int result = preparedStatement.executeUpdate();
			if(result>0)
			{
				return "Success";
			}
			System.out.println(result);
		} catch (SQLException e) {	
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			dbUtils.closeConnection(connection);
		}
		return "Fail";

	}

	@Override
	public Optional<Employee> updateEmployee(String empId, Employee employee) {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String query = " Update employees set firstName = ? , lastName = ? , extension = ? , jobTitle = ? , email = ? , officeCode = ? , reportsTo = ?, employeeNumber = ?  where employeeNumber = ?";
		connection = dbUtils.getConnection();
		try {
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, employee.getFirstName());
			preparedStatement.setString(2, employee.getLastName());
			preparedStatement.setString(3, employee.getExtension());
			preparedStatement.setString(4, employee.getJobTitle());
			preparedStatement.setString(5, employee.getEmail());
			preparedStatement.setString(6, employee.getOfficeCode());
			preparedStatement.setInt(7, employee.getReportsTo());
			preparedStatement.setInt(8, employee.getEmployeeNumber());
			preparedStatement.setInt(9, Integer.parseInt(empId));
			int result = preparedStatement.executeUpdate();
//			System.out.println(result);

			if(result>0)
			{
				System.out.println("Updated");
				return Optional.of(employee);
			}
			else
			{
				System.out.println("Invalid");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			dbUtils.closeConnection(connection);
		}
		
		
		return Optional.empty();
	}

	@Override
	public String deleteEmployee(String empId) {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String query = "Delete from employees where employeeNumber = ? ";
		connection = dbUtils.getConnection();
		try {
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, Integer.parseInt(empId));
			int resultSet = preparedStatement.executeUpdate();
//			System.out.println(resultSet);
			if(resultSet>0)
			{
				return "Successfully deleted";
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			dbUtils.closeConnection(connection);
		}
		return "There is no data with your id";
	}

	@Override
	public Optional<Employee> getEmployeeById(String empId) {
		// TODO Auto-generated method stub
		Connection connection = null;
//		Statement statement = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		
		String query = "Select * from employees where employeeNumber = ? ";
		connection = dbUtils.getConnection();
		try {
		//  Prepared Statement
		//  your query is precompiled in case of preparedstatement
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, Integer.parseInt(empId));
			resultSet = preparedStatement.executeQuery();

		// Normal Statement			
//			statement = connection.createStatement();
//			resultSet = statement.executeQuery(query);
			
			if(resultSet.next()) {
				Employee employee = new Employee();
				employee.setEmployeeNumber(resultSet.getInt("employeeNumber"));
				employee.setFirstName(resultSet.getString("firstName"));
				employee.setLastName(resultSet.getString("lastName"));
				employee.setJobTitle(resultSet.getString("jobTitle"));
				employee.setOfficeCode(resultSet.getString("officeCode"));
				employee.setReportsTo(resultSet.getInt("reportsTo"));
				System.out.println(employee);
				return Optional.of(employee);
			}
			
			else {
				
				System.out.println("There are no records");
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			dbUtils.closeConnection(connection);
		}
		
		return Optional.empty();
	}

	@Override
	public Optional<List<Employee>> getEmployees() {
		// TODO Auto-generated method stub
		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		List<Employee> employees = new ArrayList<Employee>();
		
		String query = "Select * from employees";
		connection = dbUtils.getConnection();
		try {
			
			
		// Normal statement
			statement = connection.createStatement();
			resultSet = statement.executeQuery(query);
			// resultSet.next()=> it will check whether the next record is there or not
			// we collected the data in terms of employee object
			while(resultSet.next())
			{
				Employee employee = new Employee();
				employee.setEmployeeNumber(resultSet.getInt("employeeNumber"));
				employee.setFirstName(resultSet.getString("firstName"));
				employee.setLastName(resultSet.getString("lastName"));
				employee.setJobTitle(resultSet.getString("jobTitle"));
				employee.setOfficeCode(resultSet.getString("officeCode"));
				employee.setReportsTo(resultSet.getInt("reportsTo"));
//				System.out.println(employee);
				employees.add(employee);
				
			}
			return Optional.of(employees);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			dbUtils.closeConnection(connection);
		}
		return Optional.empty();
	}

	@Override
	public boolean employeeExistsById(String empId) {
		// TODO Auto-generated method stub
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
	
		String query = "Select employeeNumber from employees where employeeNumber = ?";
		connection = dbUtils.getConnection();
		try {
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, Integer.parseInt(empId));
			resultSet = preparedStatement.executeQuery();
//			System.out.println(resultSet);
			System.out.println(resultSet.getString("employeeNumber"));
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			dbUtils.closeConnection(connection);
		}
		return false;
	}

	

}
