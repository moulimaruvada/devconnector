package com.tavant.springboot.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tavant.springboot.model.Customer;
import com.tavant.springboot.model.Office;
import com.tavant.springboot.utils.DBUtils;

@Repository
public class CustomerDAOImpl implements CustomerDAO {

	@Autowired
	DBUtils dbUtils;
	
	@Override
	public String addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		String insertStatement = "insert into customers(customerNumber,customerName,contactLastName,contactFirstName,phone,addressLine1,addressLine2,city,state,postalCode,country,salesRepEmployeeNumber,creditLimit) values(?,?,?,?,?,?,?,?,?,?,?,?,?)";
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		connection = dbUtils.getConnection();
		
		try {
			preparedStatement = connection.prepareStatement(insertStatement);
			preparedStatement.setInt(1, customer.getCustomerNumber());
			preparedStatement.setString(2, customer.getCustomerName());
			preparedStatement.setString(3, customer.getContactLastName());
			preparedStatement.setString(4, customer.getContactFirstName());
			preparedStatement.setString(5, customer.getPhone());
			preparedStatement.setString(6, customer.getAddressLine1());
			preparedStatement.setString(7, customer.getAddressLine2());
			preparedStatement.setString(8, customer.getCity());
			preparedStatement.setString(9, customer.getState());
			preparedStatement.setString(10, customer.getPostalCode());
			preparedStatement.setString(11, customer.getCountry());
			preparedStatement.setInt(12, customer.getSalesRepEmployeeNumber());
			preparedStatement.setFloat(13, customer.getCreditLimit());
			int result = preparedStatement.executeUpdate();
			if(result>0)
			{
				return "Success";
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			dbUtils.closeConnection(connection);
		}
		
		return "Fail";
	}

	@Override
	public Optional<Customer> updateCustomer(String custId, Customer customer) {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String insertStatement = "Update customers set customerNumber = ? ,customerName = ? , contactLastName = ? , contactFirstName = ? , phone = ? , addressLine1 = ? , addressLine2 = ? , city = ? , state = ? , postalCode = ? , country = ? , salesRepEmployeeNumber = ? , creditLimit = ? where customerNumber = ?";
		connection = dbUtils.getConnection();
		try {
			preparedStatement = connection.prepareStatement(insertStatement);
			preparedStatement.setInt(1, customer.getCustomerNumber());
			preparedStatement.setString(2, customer.getCustomerName());
			preparedStatement.setString(3, customer.getContactLastName());
			preparedStatement.setString(4, customer.getContactFirstName());
			preparedStatement.setString(5, customer.getPhone());
			preparedStatement.setString(6, customer.getAddressLine1());
			preparedStatement.setString(7, customer.getAddressLine2());
			preparedStatement.setString(8, customer.getCity());
			preparedStatement.setString(9, customer.getState());
			preparedStatement.setString(10, customer.getPostalCode());
			preparedStatement.setString(11, customer.getCountry());
			preparedStatement.setInt(12, customer.getSalesRepEmployeeNumber());
			preparedStatement.setFloat(13, customer.getCreditLimit());
			preparedStatement.setInt(14, Integer.parseInt(custId));
			int result = preparedStatement.executeUpdate();
//			System.out.println(result);

			if(result>0)
			{
				System.out.println("Updated");
				return Optional.of(customer);
			}
			else
			{
				System.out.println("Invalid");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			dbUtils.closeConnection(connection);
		}
		
		
		return Optional.empty();
	}

	@Override
	public String deleteCustomer(String custId) {
		// TODO Auto-generated method stub
		String insertStatement = "delete from customers where customerNumber = ? ";
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		connection = dbUtils.getConnection();
		try {
			preparedStatement = connection.prepareStatement(insertStatement);
			preparedStatement.setInt(1,Integer.parseInt(custId));
			int resultSet = preparedStatement.executeUpdate();
			
			if(resultSet>0)
			{
				return "Successfully deleted";
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			
			dbUtils.closeConnection(connection);
		}
		return "There is no data with your id";
	}

	@Override
	public Optional<Customer> getCustomerById(String custId) {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		connection = dbUtils.getConnection();
		String insertStatement = "select * from customers where customerNumber = ?";
		try {
			preparedStatement = connection.prepareStatement(insertStatement);
			preparedStatement.setInt(1, Integer.parseInt(custId));
			resultSet = preparedStatement.executeQuery();
			
			if(resultSet.next()) {
				Customer customer = new Customer();
				customer.setCustomerNumber(resultSet.getInt("customerNumber"));
				customer.setCustomerName(resultSet.getString("customerName"));
				customer.setContactLastName(resultSet.getString("contactLastName"));
				customer.setContactFirstName(resultSet.getString("contactFirstName"));
				customer.setPhone(resultSet.getString("phone"));
				customer.setAddressLine1(resultSet.getString("addressLine1"));
				customer.setAddressLine2(resultSet.getString("addressLine2"));
				customer.setCity(resultSet.getString("city"));
				customer.setState(resultSet.getString("state"));
				customer.setPostalCode(resultSet.getString("postalCode"));
				customer.setCountry(resultSet.getString("country"));
				customer.setSalesRepEmployeeNumber(resultSet.getInt("salesRepEmployeeNumber"));
				customer.setCreditLimit(resultSet.getFloat("creditLimit"));
				System.out.println(customer);
				return Optional.of(customer);
			}
			
			else {
				
				System.out.println("There are no records");
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			dbUtils.closeConnection(connection);
		}
		
		return Optional.empty();
	}

	@Override
	public Optional<List<Customer>> getCustomers() {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		List<Customer> customers = new ArrayList<Customer>();
		connection = dbUtils.getConnection();
		String insertStatement = "select * from customers ";
		try {
			preparedStatement = connection.prepareStatement(insertStatement);
			resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()) {
				Customer customer = new Customer();
				customer.setCustomerNumber(resultSet.getInt("customerNumber"));
				customer.setCustomerName(resultSet.getString("customerName"));
				customer.setContactLastName(resultSet.getString("contactLastName"));
				customer.setContactFirstName(resultSet.getString("contactFirstName"));
				customer.setPhone(resultSet.getString("phone"));
				customer.setAddressLine1(resultSet.getString("addressLine1"));
				customer.setAddressLine2(resultSet.getString("addressLine2"));
				customer.setCity(resultSet.getString("city"));
				customer.setState(resultSet.getString("state"));
				customer.setPostalCode(resultSet.getString("postalCode"));
				customer.setCountry(resultSet.getString("country"));
				customer.setSalesRepEmployeeNumber(resultSet.getInt("salesRepEmployeeNumber"));
				customer.setCreditLimit(resultSet.getFloat("creditLimit"));
//				System.out.println(office);
				customers.add(customer);
			}
			
			return Optional.ofNullable(customers);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			dbUtils.closeConnection(connection);
		}
		return Optional.empty();
	}

	@Override
	public boolean customerExistsById(String custId) {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
	
		String query = "Select customerNumber from customers where customerNumber = ?";
		connection = dbUtils.getConnection();
		try {
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, Integer.parseInt(custId));
			resultSet = preparedStatement.executeQuery();
//			System.out.println(resultSet);
			System.out.println(resultSet.getString("customerNumber"));
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			dbUtils.closeConnection(connection);
		}
		return false;
	}

}
