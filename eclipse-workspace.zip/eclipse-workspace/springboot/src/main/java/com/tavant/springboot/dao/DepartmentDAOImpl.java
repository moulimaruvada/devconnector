package com.tavant.springboot.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tavant.springboot.model.Department;
import com.tavant.springboot.utils.DBUtils;

@Repository
public class DepartmentDAOImpl implements DepartmentDAO {
	
	@Autowired
	DBUtils dbUtils;
//	
//	public DepartmentDAOImpl() {
//		// TODO Auto-generated constructor stub
//		
//	}
//	private static DepartmentDAO departmentDAOImpl;
//	
//	public static DepartmentDAO getInstance() {
//		if(departmentDAOImpl==null)
//		{
//			departmentDAOImpl = new DepartmentDAOImpl();
//			return departmentDAOImpl;
//		}
//		return departmentDAOImpl;
//	}

	
	private List<Department> departments = new ArrayList<Department>();
	
	@Override
	public String addDepartment(Department department) {
		// TODO Auto-generated method stub
		boolean result = departments.add(department);
		if(result) return "Success";
		else return "Fail";
		
	}

	@Override
	public Department updateDepartment(String depId, Department department) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteDepartment(String depId) {
		// TODO Auto-generated method stub
		boolean result = departments.remove(this.getDepartmentById(depId));
		if(result) return "Success";
		else return "Fail";

	}

	@Override
	public Department getDepartmentById(String depId) {
		// TODO Auto-generated method stub
		
		for(Department department : departments)
		{
			if(department.getDepId(depId).equals(depId))
			{
				return department;
			}
		}
		return null;
	}

	@Override
	public List<Department> getDepartments() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean departmentExistsById(String depId) {
		// TODO Auto-generated method stub
		return departments.contains(this.getDepartmentById(depId));
	}

}
