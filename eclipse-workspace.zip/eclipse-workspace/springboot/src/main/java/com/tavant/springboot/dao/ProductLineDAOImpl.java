package com.tavant.springboot.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tavant.springboot.model.Office;
import com.tavant.springboot.model.ProductLine;
import com.tavant.springboot.utils.DBUtils;

@Repository
public class ProductLineDAOImpl implements ProductLineDAO {

	@Autowired
	DBUtils dbUtils;
	
	@Override
	public String addProductLine(ProductLine productLine) {
		// TODO Auto-generated method stub
		String insertStatement = "insert into productlines(productLine,textDescription,htmlDescription,image) values(?,?,?,?)";
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		connection = dbUtils.getConnection();
		
		try {
			preparedStatement = connection.prepareStatement(insertStatement);
			preparedStatement.setString(1, productLine.getProductLine());
			preparedStatement.setString(2, productLine.getTextDescription());
			preparedStatement.setString(3, productLine.getHtmlDescription());
			preparedStatement.setString(4, productLine.getImage());
			int result = preparedStatement.executeUpdate();
			if(result>0)
			{
				return "Success";
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			dbUtils.closeConnection(connection);
		}
		
		return "Fail";
	}

	@Override
	public Optional<ProductLine> updateProductLine(String PrlId, ProductLine productLine) {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String query = " Update productlines set productLine = ? , textDescription = ? , htmlDescription = ? , image = ? where productLine = ?";
		connection = dbUtils.getConnection();
		try {
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, productLine.getProductLine());
			preparedStatement.setString(2, productLine.getTextDescription());
			preparedStatement.setString(3, productLine.getHtmlDescription());
			preparedStatement.setString(4, productLine.getImage());
			preparedStatement.setString(5, PrlId);
			int result = preparedStatement.executeUpdate();
//			System.out.println(result);

			if(result>0)
			{
				System.out.println("Updated");
				return Optional.of(productLine);
			}
			else
			{
				System.out.println("Invalid");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			dbUtils.closeConnection(connection);
		}
		
		
		return Optional.empty();
	}

	@Override
	public String deleteProductLine(String PrlId) {
		// TODO Auto-generated method stub
		String insertStatement = "delete from productLines where productLine = ? ";
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		connection = dbUtils.getConnection();
		try {
			preparedStatement = connection.prepareStatement(insertStatement);
			preparedStatement.setString(1,PrlId);
			int resultSet = preparedStatement.executeUpdate();
			
			if(resultSet>0)
			{
				return "Successfully deleted";
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			
			dbUtils.closeConnection(connection);
		}
		return "There is no data with your id";
	}

	@Override
	public Optional<ProductLine> getProductLineById(String PrlId) {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		connection = dbUtils.getConnection();
		String insertStatement = "select * from productlines where productLine = ?";
		try {
			preparedStatement = connection.prepareStatement(insertStatement);
			preparedStatement.setString(1, PrlId);
			resultSet = preparedStatement.executeQuery();
			
			if(resultSet.next()) {
				ProductLine productLine = new ProductLine();
				productLine.setProductLine(resultSet.getString("productLine"));
				productLine.setTextDescription(resultSet.getString("textDescription"));
				productLine.setHtmlDescription(resultSet.getString("htmlDescription"));
				productLine.setImage(resultSet.getString("image"));
				System.out.println(productLine);
				return Optional.of(productLine);
			}
			
			else {
				
				System.out.println("There are no records");
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			dbUtils.closeConnection(connection);
		}
		
		return Optional.empty();
	}

	@Override
	public Optional<List<ProductLine>> getProductLines() {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		List<ProductLine> productLines = new ArrayList<ProductLine>();
		connection = dbUtils.getConnection();
		String insertStatement = "select * from productlines ";
		try {
			preparedStatement = connection.prepareStatement(insertStatement);
			resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()) {
				ProductLine productLine = new ProductLine();
				productLine.setProductLine(resultSet.getString("productLine"));
				productLine.setTextDescription(resultSet.getString("textDescription"));
				productLine.setHtmlDescription(resultSet.getString("htmlDescription"));
				productLine.setImage(resultSet.getString("image"));
//				System.out.println(office);
				productLines.add(productLine);
			}
			
			return Optional.ofNullable(productLines);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			dbUtils.closeConnection(connection);
		}
		return Optional.empty();
	}

	@Override
	public boolean productLineExistsById(String PrlId) {
		// TODO Auto-generated method stub
		return false;
	}

}
