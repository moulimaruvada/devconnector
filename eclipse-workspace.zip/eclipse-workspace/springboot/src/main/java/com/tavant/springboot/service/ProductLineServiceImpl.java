	package com.tavant.springboot.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tavant.springboot.dao.ProductLineDAOImpl;
import com.tavant.springboot.model.ProductLine;

@Service("productLine")
public class ProductLineServiceImpl implements ProductLineService {

	@Autowired
	ProductLineDAOImpl productLineDAO;
	
	@Override
	public String addProductLine(ProductLine productLine) {
		// TODO Auto-generated method stub
		return productLineDAO.addProductLine(productLine);
	}

	@Override
	public Optional<ProductLine> updateProductLine(String PrlId, ProductLine productLine) {
		// TODO Auto-generated method stub
		return productLineDAO.updateProductLine(PrlId, productLine);
	}

	@Override
	public String deleteProductLine(String PrlId) {
		// TODO Auto-generated method stub
		return productLineDAO.deleteProductLine(PrlId);
	}

	@Override
	public Optional<ProductLine> getProductLineById(String PrlId) {
		// TODO Auto-generated method stub
		return productLineDAO.getProductLineById(PrlId);
	}

	@Override
	public Optional<List<ProductLine>> getProductLines() {
		// TODO Auto-generated method stub
		return productLineDAO.getProductLines();
	}

	@Override
	public boolean productLineExistsById(String PrlId) {
		// TODO Auto-generated method stub
		return productLineDAO.productLineExistsById(PrlId);
	}

}
