package com.tavant.springboot.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tavant.springboot.dao.CustomerDAOImpl;
import com.tavant.springboot.model.Customer;

@Service("customerService")
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerDAOImpl customerDAO;
	
	@Override
	public String addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return customerDAO.addCustomer(customer);
	}

	@Override
	public Optional<Customer> updateCustomer(String custId, Customer customer) {
		// TODO Auto-generated method stub
		return customerDAO.updateCustomer(custId, customer);
	}

	@Override
	public String deleteCustomer(String custId) {
		// TODO Auto-generated method stub
		return customerDAO.deleteCustomer(custId);
	}

	@Override
	public Optional<Customer> getCustomerById(String custId) {
		// TODO Auto-generated method stub
		return customerDAO.getCustomerById(custId);
	}

	@Override
	public Optional<List<Customer>> getCustomers() {
		// TODO Auto-generated method stub
		return customerDAO.getCustomers();
	}

	@Override
	public boolean customerExistsById(String custId) {
		// TODO Auto-generated method stub
		return customerDAO.customerExistsById(custId);
	}

}
