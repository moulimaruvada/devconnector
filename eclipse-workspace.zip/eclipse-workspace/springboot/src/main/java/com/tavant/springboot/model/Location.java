package com.tavant.springboot.model;

import com.tavant.springboot.exception.InvalidLocIdException;




public class Location {
		
//		public Location(String locId, String locName) throws InvalidLocIdException {
//		super();
//		this.setLocId(locId);
//		this.locName = locName;
//	}
		
		
		
		public String locId;
		public String locName;
		
		
		
		@Override
		public String toString() {
			return "Location [locId=" + locId + ", locName=" + locName + "]";
		}


		public String getLocName(String locName) {
			return locName;
		}
		

		public void setLocName(String locName) {
			this.locName = locName;
		}


		public String getLocId(String locId) {
			return locId;
		}


		public void setLocId(String locId) throws InvalidLocIdException {
			if(locId.length()<6)
			{
				throw new InvalidLocIdException("Enter a Valid Input");
			}
			else
			{
				this.locId = locId;
			}
		}
}

