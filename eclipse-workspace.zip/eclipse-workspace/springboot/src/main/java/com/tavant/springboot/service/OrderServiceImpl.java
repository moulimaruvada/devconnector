package com.tavant.springboot.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tavant.springboot.dao.OrderDAOImpl;
import com.tavant.springboot.model.Order;

@Service("order")
public class OrderServiceImpl implements OrderService {

	@Autowired
	OrderDAOImpl orderDAOImpl;
	
	@Override
	public String addOrder(Order order) {
		// TODO Auto-generated method stub
		return orderDAOImpl.addOrder(order);
	}

	@Override
	public Optional<Order> updateOrder(String orderId, Order order) {
		// TODO Auto-generated method stub
		return orderDAOImpl.updateOrder(orderId, order);
	}

	@Override
	public String deleteOrder(String orderId) {
		// TODO Auto-generated method stub
		return orderDAOImpl.deleteOrder(orderId);
	}

	@Override
	public Optional<Order> getOrderById(String orderId) {
		// TODO Auto-generated method stub
		return orderDAOImpl.getOrderById(orderId);
	}

	@Override
	public Optional<List<Order>> getOrders() {
		// TODO Auto-generated method stub
		return orderDAOImpl.getOrders();
	}

	@Override
	public boolean OrderExistsById(String orderId) {
		// TODO Auto-generated method stub
		return orderDAOImpl.OrderExistsById(orderId);
	}

}
