
package com.tavant.springboot.service;

import java.util.List;

import com.tavant.springboot.model.Department;

public interface DepartmentService {
	
	public String addDepartment(Department department);
	public Department updateDepartment(String depId, Department department);
	public String deleteDepartment(String depId);
	public Department getDepartmentById(String depId);
	public List<Department> getDepartments();
	
	public boolean departmentExistsById(String depId);

}
