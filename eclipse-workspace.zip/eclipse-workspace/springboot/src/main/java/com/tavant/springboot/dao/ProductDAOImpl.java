package com.tavant.springboot.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tavant.springboot.model.Product;
import com.tavant.springboot.utils.DBUtils;

@Repository
public class ProductDAOImpl implements ProductDAO {

	@Autowired
	DBUtils dbUtils;
	@Override
	public String addProduct(Product product) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<Product> updateProduct(String prodId, Product product) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteProduct(String prodId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<Product> getProductById(String prodId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<List<Product>> getProducts() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean productExistsById(String prodId) {
		// TODO Auto-generated method stub
		return false;
	}

}
