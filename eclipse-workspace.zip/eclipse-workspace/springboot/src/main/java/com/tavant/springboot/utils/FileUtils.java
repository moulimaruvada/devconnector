package com.tavant.springboot.utils;

import java.io.InputStream;
import java.util.Properties;

import org.springframework.stereotype.Component;

public class FileUtils {
	
	
	
//private FileUtils() {
//
//}
//
//private static FileUtils utils;
//	
//	public static FileUtils getInstance() {
//		if (utils == null) {
//			synchronized (FileUtils.class) {
//				if (utils == null) {
//					utils = new FileUtils();
//				}
//				return utils;
//			}
//		}
//		return utils;
//	}
	
	public Properties readProperties() {
		
		Properties properties = new Properties();
		try(InputStream inputStream = getClass()
				.getClassLoader()
				.getResourceAsStream("application.properties")) {
			if(inputStream==null)
			{
				System.out.println("File is not available");
			}
			else {
//				System.out.println("Ready to read the file content");
				properties.load(inputStream);
//				properties.forEach((k,v)->{
//					System.out.println(k+"     "+v);
//					
//				});
			}
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		return properties;
		
		
		
	}

}




