package com.tavant.springboot.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tavant.springboot.dao.OfficeDAOImpl;
import com.tavant.springboot.model.Office;

@Service("officeService")
public class OfficeServiceImpl implements OfficeService {

	@Autowired
	OfficeDAOImpl officeDAO;
	
	@Override
	public String addOffice(Office office) {
		// TODO Auto-generated method stub
		return officeDAO.addOffice(office);
	}

	@Override
	public Optional<Office> updateOffice(String offId, Office office) {
		// TODO Auto-generated method stub
		return officeDAO.updateOffice(offId, office);
	}

	@Override
	public String deleteOffice(String offId) {
		// TODO Auto-generated method stub
		return officeDAO.deleteOffice(offId);
	}

	@Override
	public Optional<Office> getOfficeById(String offId) {
		// TODO Auto-generated method stub
		return officeDAO.getOfficeById(offId);
	}

	@Override
	public Optional<List<Office>> getOffices() {
		// TODO Auto-generated method stub
		return officeDAO.getOffices();
	}

	@Override
	public boolean officeExistsById(String offId) {
		// TODO Auto-generated method stub
		return officeDAO.officeExistsById(offId);
	}

}
