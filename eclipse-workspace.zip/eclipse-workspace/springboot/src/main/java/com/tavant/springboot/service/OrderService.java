package com.tavant.springboot.service;

import java.util.List;
import java.util.Optional;

import com.tavant.springboot.model.Order;

public interface OrderService {

	public String addOrder(Order order);
	public Optional<Order> updateOrder(String orderId,Order order);
	public String deleteOrder(String orderId);
	public Optional<Order> getOrderById(String orderId);
	public Optional<List<Order>> getOrders();
	
	public boolean OrderExistsById(String orderId);
	
}
