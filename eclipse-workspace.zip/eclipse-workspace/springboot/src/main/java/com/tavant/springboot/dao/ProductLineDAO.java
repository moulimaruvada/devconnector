package com.tavant.springboot.dao;

import java.util.List;
import java.util.Optional;

import com.tavant.springboot.model.ProductLine;

public interface ProductLineDAO {
	
	public String addProductLine(ProductLine productLine);
	public Optional<ProductLine> updateProductLine(String PrlId,ProductLine productLine);
	public String deleteProductLine(String PrlId);
	public Optional<ProductLine> getProductLineById(String PrlId);
	public Optional<List<ProductLine>> getProductLines();
	
	public boolean productLineExistsById(String PrlId);

}
