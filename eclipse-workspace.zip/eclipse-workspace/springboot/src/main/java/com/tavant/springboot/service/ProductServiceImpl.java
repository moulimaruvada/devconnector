package com.tavant.springboot.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tavant.springboot.dao.ProductDAOImpl;
import com.tavant.springboot.model.Product;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductDAOImpl productDAOImpl;
	
	@Override
	public String addProduct(Product product) {
		// TODO Auto-generated method stub
		return productDAOImpl.addProduct(product);
	}

	@Override
	public Optional<Product> updateProduct(String prodId, Product product) {
		// TODO Auto-generated method stub
		return productDAOImpl.updateProduct(prodId, product);
	}

	@Override
	public String deleteProduct(String prodId) {
		// TODO Auto-generated method stub
		return productDAOImpl.deleteProduct(prodId);
	}

	@Override
	public Optional<Product> getProductById(String prodId) {
		// TODO Auto-generated method stub
		return productDAOImpl.getProductById(prodId);
	}

	@Override
	public Optional<List<Product>> getProducts() {
		// TODO Auto-generated method stub
		return productDAOImpl.getProducts();
	}

	@Override
	public boolean productExistsById(String prodId) {
		// TODO Auto-generated method stub
		return productDAOImpl.productExistsById(prodId);
	}

}
