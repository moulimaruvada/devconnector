package com.tavant.springboot.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class OrderDetail {

	private int orderNumber;
	private String productCode;
	private int quantityOrdered;
	private float priceEach;
	private int orderLineNumber;
	
}
