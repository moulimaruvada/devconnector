package com.tavant.springboot.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tavant.springboot.model.Office;
import com.tavant.springboot.model.Order;
import com.tavant.springboot.utils.DBUtils;

@Repository
public class OrderDAOImpl implements OrderDAO {

	@Autowired
	DBUtils dbUtils;
	
	@Override
	public String addOrder(Order order) {
		// TODO Auto-generated method stub
		String insertStatement = "insert into orders(orderNumber,orderDate,requiredDate,shippedDate,status,comments,customerNumber) values(?,?,?,?,?,?,?)";
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		connection = dbUtils.getConnection();
		
		try {
			preparedStatement = connection.prepareStatement(insertStatement);
			preparedStatement.setInt(1, order.getOrderNumber());
			preparedStatement.setString(2, order.getOrderDate());
			preparedStatement.setString(3, order.getRequiredDate());
			preparedStatement.setString(4, order.getShippedDate());
			preparedStatement.setString(5, order.getStatus());
			preparedStatement.setString(6, order.getComments());
			preparedStatement.setInt(7, order.getCustomerNumber());
			int result = preparedStatement.executeUpdate();
			if(result>0)
			{
				return "Success";
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			dbUtils.closeConnection(connection);
		}
		
		return "Fail";
	}

	@Override
	public Optional<Order> updateOrder(String orderId, Order order) {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String query = " Update orders set orderNumber = ? , orderDate = ? , requiredDate = ? , shippedDate = ? , status = ? , comments = ? , customerNumber = ? where orderNumber = ?";
		connection = dbUtils.getConnection();
		try {
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, order.getOrderNumber());
			preparedStatement.setString(2, order.getOrderDate());
			preparedStatement.setString(3, order.getRequiredDate());
			preparedStatement.setString(4, order.getShippedDate());
			preparedStatement.setString(5, order.getStatus());
			preparedStatement.setString(6, order.getComments());
			preparedStatement.setInt(7, order.getCustomerNumber());
			preparedStatement.setInt(8, Integer.parseInt(orderId));
			int result = preparedStatement.executeUpdate();
//			System.out.println(result);

			if(result>0)
			{
				System.out.println("Updated");
				return Optional.of(order);
			}
			else
			{
				System.out.println("Invalid");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			dbUtils.closeConnection(connection);
		}
		
		
		return Optional.empty();
	}

	@Override
	public String deleteOrder(String orderId) {
		// TODO Auto-generated method stub
		String insertStatement = "delete from orders where orderNumber = ? ";
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		connection = dbUtils.getConnection();
		try {
			preparedStatement = connection.prepareStatement(insertStatement);
			preparedStatement.setInt(1,Integer.parseInt(orderId));
			int resultSet = preparedStatement.executeUpdate();
			
			if(resultSet>0)
			{
				return "Successfully deleted";
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			
			dbUtils.closeConnection(connection);
		}
		return "There is no data with your id";
	}

	@Override
	public Optional<Order> getOrderById(String orderId) {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		connection = dbUtils.getConnection();
		String insertStatement = "select * from orders where orderNumber = ?";
		try {
			preparedStatement = connection.prepareStatement(insertStatement);
			preparedStatement.setInt(1, Integer.parseInt(orderId));
			resultSet = preparedStatement.executeQuery();
			
			if(resultSet.next()) {
				Order order = new Order();
				order.setOrderNumber(resultSet.getInt("orderNumber"));
				order.setOrderDate(resultSet.getString("orderDate"));
				order.setRequiredDate(resultSet.getString("requiredDate"));
				order.setShippedDate(resultSet.getString("shippedDate"));
				order.setStatus(resultSet.getString("status"));
				order.setComments(resultSet.getString("comments"));
				order.setCustomerNumber(resultSet.getInt("customerNumber"));
				System.out.println(order);
				return Optional.of(order);
			}
			
			else {
				
				System.out.println("There are no records");
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			dbUtils.closeConnection(connection);
		}
		
		return Optional.empty();
	}

	@Override
	public Optional<List<Order>> getOrders() {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		List<Order> orders = new ArrayList<Order>();
		connection = dbUtils.getConnection();
		String insertStatement = "select * from orders ";
		try {
			preparedStatement = connection.prepareStatement(insertStatement);
			resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()) {
				Order order = new Order();
				order.setOrderNumber(resultSet.getInt("orderNumber"));
				order.setOrderDate(resultSet.getString("orderDate"));
				order.setRequiredDate(resultSet.getString("requiredDate"));
				order.setShippedDate(resultSet.getString("shippedDate"));
				order.setStatus(resultSet.getString("status"));
				order.setComments(resultSet.getString("comments"));
				order.setCustomerNumber(resultSet.getInt("customerNumber"));
//				System.out.println(office);
				orders.add(order);
			}
			
			return Optional.ofNullable(orders);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			dbUtils.closeConnection(connection);
		}
		return Optional.empty();
	}

	@Override
	public boolean OrderExistsById(String orderId) {
		// TODO Auto-generated method stub
		return false;
	}

}
