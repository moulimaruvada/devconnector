package com.tavant.springboot.service;

import java.util.List;
import java.util.Optional;

import com.tavant.springboot.model.ProductLine;

public interface ProductLineService {

	public String addProductLine(ProductLine productLine);
	public Optional<ProductLine> updateProductLine(String PrlId,ProductLine productLine);
	public String deleteProductLine(String PrlId);
	public Optional<ProductLine> getProductLineById(String PrlId);
	public Optional<List<ProductLine>> getProductLines();
	
	public boolean productLineExistsById(String PrlId);
}
