package com.tavant.springboot;

import java.util.List;
import java.util.Optional;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.tavant.springboot.model.Customer;
import com.tavant.springboot.model.Office;
import com.tavant.springboot.model.Order;
import com.tavant.springboot.model.ProductLine;
import com.tavant.springboot.service.CustomerService;
import com.tavant.springboot.service.EmployeeService;
import com.tavant.springboot.service.OfficeService;
import com.tavant.springboot.service.OrderService;
import com.tavant.springboot.service.ProductLineService;

@SpringBootApplication
public class SpringbootApplication {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(SpringbootApplication.class, args);
		EmployeeService employeeService = context.getBean(EmployeeService.class);
		OfficeService officeService = context.getBean(OfficeService.class); 
		CustomerService customerService = context.getBean(CustomerService.class);
		OrderService orderService = context.getBean(OrderService.class);
		ProductLineService productLineService = context.getBean(ProductLineService.class);
		System.out.println(employeeService!=null);
		

//		Office office = new Office("9","VSKP","9232389793","aa12","ashgmailcom","AP","India","hah878","Ind");
//		String res = officeService.deleteOffice("9");
//		System.out.println("delete result "+res);
//		Optional<Office> res = officeService.updateOffice("8", office);
//		System.out.println(res);
//		officeService.getOfficeById("9");
//		Optional<List<Office>> res = officeService.getOffices();
//		if(res.isPresent())
//		{
//			res.get().forEach(System.out::println);
//		}
//		else
//		{
//			System.out.println("No records found");
//		}
//		officeService.officeExistsById("9");
		
		

//		Customer customer = new Customer(500,"re","mo","li","342324","sda","asda","ds","fef","4rsfe","df",1612,23);
//		String res = customerService.deleteCustomer("501");
//		System.out.println(res);
//		customerService.getCustomerById("500");
//		Optional<List<Customer>> res = customerService.getCustomers();
//		if(res.isPresent())
//		{
//			res.get().forEach(System.out::println);
//		}
//		else
//		{
//			System.out.println("No records found");
//		}
		
		
//		Order order = new Order(10501,"2334-2-21","1232-3-12","4343-3-12","lol","jkajs",119);
//		Optional<Order> res = orderService.updateOrder("10500", order);
//		System.out.println(res);
//		String res = orderService.deleteOrder("10501");
//		System.out.println(res);
//		orderService.getOrderById("10425");
//		Optional<List<Order>> res = orderService.getOrders();
//		if(res.isPresent())
//		{
//			res.get().forEach(System.out::println);
//		}
//		else
//		{
//			System.out.println("No records found");
//		}
		
		
//		ProductLine productLine = new ProductLine("Cab", "oboin", "asda", "sda");
//		Optional<ProductLine> res = productLineService.updateProductLine("Bike", productLine);
//		System.out.println(res);
//		String res = productLineService.deleteProductLine("Cab");
//		System.out.println(res);
//		productLineService.getProductLineById("Trains");
//		Optional<List<ProductLine>> res = productLineService.getProductLines();
//		if(res.isPresent())
//		{
//			res.get().forEach(System.out::println);
//		}
//		else
//		{
//			System.out.println("No records found");
//		}
	}

}
