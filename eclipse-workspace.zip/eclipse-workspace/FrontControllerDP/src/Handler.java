
public class Handler {

	private View1 view1;
	private View2 view2;
	
	public Handler() {
		
		view1 = new View1();
		view2 = new View2();
	}
	public void handle(String request) {
	
		if("view1".equals(request))
		{
			view1.show();
		}
		else if("view2".equals(request))
		{
			view2.show();
		}
		
	}
}
