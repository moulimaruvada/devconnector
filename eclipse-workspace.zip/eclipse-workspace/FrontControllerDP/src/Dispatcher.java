
public class Dispatcher {

	private Handler handler; 
	
	public Dispatcher() {
		// TODO Auto-generated constructor stub
		handler = new Handler();
	}
	
	private static Dispatcher dispatcher;
	
	public static Dispatcher getInstance() {
		if(dispatcher==null)
		{
			dispatcher = new Dispatcher();
			return dispatcher;
		}
		return dispatcher;
	}
	
	public void dispatch(String request)
	{
		handler.handle(request);
	}

}
