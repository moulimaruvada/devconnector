
public class FrontControl {

	Dispatcher dispatcher = new Dispatcher(); 
	
	public FrontControl() {
		// TODO Auto-generated constructor stub
	}
	
	private static FrontControl frontcontrol;

	
	
	public static FrontControl getInstance() {
		if(frontcontrol==null)
		{
			frontcontrol = new FrontControl();
			return frontcontrol;
		}
		return frontcontrol;
	}
	
	
	public void dispatchrequest(String request ) {
		
		
		dispatcher.dispatch(request);
	}
}
