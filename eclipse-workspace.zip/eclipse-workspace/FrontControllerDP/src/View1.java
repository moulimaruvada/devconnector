
public class View1 {
	
	 public void show() {
		 System.out.println("hello from view1");
	}
}
