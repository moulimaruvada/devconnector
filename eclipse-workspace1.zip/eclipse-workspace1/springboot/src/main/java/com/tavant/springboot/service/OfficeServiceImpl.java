package com.tavant.springboot.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tavant.springboot.dao.OfficeDAO;
import com.tavant.springboot.model.Employee;
import com.tavant.springboot.model.Office;

@Service("officeService")
public class OfficeServiceImpl implements OfficeService {

	@Autowired
	OfficeDAO officeDAO;
	
	@Override
	public boolean addOffice(Office off) {
		// TODO Auto-generated method stub
		Office office = officeDAO.save(off);
		return office!=null;
	}

	@Override
	public Optional<Office> updateOffice(String offId, Office office) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteOffice(String offId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<Office> getOfficeById(String offId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<List<Office>> getOffices() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean officeExistsById(String offId) {
		// TODO Auto-generated method stub
		return false;
	}


}
