package com.tavant.springboot.service;

import java.util.List;
import java.util.Optional;

import com.tavant.springboot.model.Payment;

public interface PaymentService {

	public boolean addPayment(Payment payment);
	public Optional<Payment> updatePayment(String payId,Payment payment);
	public String deletePayment(String payId);
	public Optional<Payment> getPaymentById(String payId);
	public Optional<List<Payment>> getPayments();
	
	public boolean PaymentExistsById(String payId);
}
