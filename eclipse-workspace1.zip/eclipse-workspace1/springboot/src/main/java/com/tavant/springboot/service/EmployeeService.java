package com.tavant.springboot.service;

import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;

import com.tavant.springboot.model.Employee;
import com.tavant.springboot.model.ICountData;

public interface EmployeeService {

	public boolean addEmployee(Employee emp);
    public Optional<Employee> updateEmployee(String empId, Employee employee);
    public String deleteEmployee(String empId);
    public Optional<Employee> getEmployeeById(int empId);
    public Optional<List<Employee>> getEmployees();
    
	public boolean employeeExistsById(int empId);
	public Employee findTopByOrderByJobTitleDesc();
	public Optional<List<Employee>> findByOfficeCode(String officeCode);
	public Optional<List<Employee>> findFirst2ByOfficeCode(String officeCode);
	public Optional<List<Employee>> findByFirstNameLike(String firstName);
//	public int countByOfficeCode(String off);

	public int countByOfficeCode();
//	public int countBySalaryGreaterThanEqual()
	public Optional<List<Object[]>> method();
	public List<ICountData> method1();
	public List<HashMap<String, Object>> employeeMap();
}
