package com.tavant.springboot.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tavant.springboot.dao.CustomerDAO;
import com.tavant.springboot.model.Customer;
import com.tavant.springboot.model.Office;

@Service("customerService")
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerDAO customerDAO;
	
	@Override
	public boolean addCustomer(Customer cust) {
		// TODO Auto-generated method stub
		Customer customer = customerDAO.save(cust);
		return customer!=null;
	}

	@Override
	public Optional<Customer> updateCustomer(String custId, Customer customer) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteCustomer(String custId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<Customer> getCustomerById(String custId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<List<Customer>> getCustomers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean customerExistsById(String custId) {
		// TODO Auto-generated method stub
		return false;
	}

	
}
