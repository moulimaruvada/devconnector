package com.tavant.springboot.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tavant.springboot.model.Office;

@Repository
public interface OfficeDAO extends JpaRepository<Office, String>{


	
}
