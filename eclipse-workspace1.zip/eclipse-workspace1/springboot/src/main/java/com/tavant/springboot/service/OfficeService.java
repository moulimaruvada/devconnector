package com.tavant.springboot.service;

import java.util.List;
import java.util.Optional;

import com.tavant.springboot.model.Office;

public interface OfficeService {

	public boolean addOffice(Office office);
	public Optional<Office> updateOffice(String offId,Office office);
	public String deleteOffice(String offId);
	public Optional<Office> getOfficeById(String offId);
	public Optional<List<Office>> getOffices();
	
	public boolean officeExistsById(String offId);
}
