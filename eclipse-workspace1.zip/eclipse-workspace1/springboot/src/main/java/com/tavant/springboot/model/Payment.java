//package com.tavant.springboot.model;
//
//import java.util.List;
//
//import javax.persistence.Entity;
//import javax.persistence.FetchType;
//import javax.persistence.Id;
//import javax.persistence.JoinColumn;
//import javax.persistence.ManyToOne;
//import javax.persistence.OneToMany;
//
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//
//@Data
//@NoArgsConstructor
//@AllArgsConstructor
//@Entity
//public class Payment {
//
//	@Id
//	private Integer customerNumber;
//	private String checkNumber;
//	private String paymentDate;
//	private float amount;
//
//}












package com.tavant.springboot.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
//@IdClass(PaymentId.class)
public class Payment implements Serializable  {

	@Id
//	@ManyToOne
//	@JoinColumn(name="customerNumber")
	private Integer customerNumber;
//	@Id
	private String checkNumber;
	private String paymentDate;
	private float amount;

}

