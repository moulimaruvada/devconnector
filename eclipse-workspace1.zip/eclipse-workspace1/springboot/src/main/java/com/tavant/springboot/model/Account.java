package com.tavant.springboot.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

@Entity
@IdClass(AccountId.class)
public class Account {

	@Id
	private String accountNumber;
	@Id
	private String accountType;
	private String firstName;
	private String lastName;
	private float balance;
}
