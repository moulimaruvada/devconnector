package com.tavant.springboot;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import com.tavant.springboot.dao.EmployeeDAO;
import com.tavant.springboot.dao.EmployeeModelRepository;
import com.tavant.springboot.model.Customer;
import com.tavant.springboot.model.Employee;
import com.tavant.springboot.model.EmployeeModel;
import com.tavant.springboot.model.Office;
import com.tavant.springboot.model.Payment;
import com.tavant.springboot.service.CustomerService;
import com.tavant.springboot.service.EmployeeService;
import com.tavant.springboot.service.OfficeService;
import com.tavant.springboot.service.PaymentService;


@SpringBootApplication
public class SpringbootApplication {
	
//	private static ApplicationContext context;
//	private static List<EmployeeModel> createEmployees() {
//	      return Arrays.asList(
//	              new EmployeeModel("Diana", "Sales", 2000),
//	              new EmployeeModel("Mike", "Sales", 1000),
//	              new EmployeeModel("Rose", "IT", 4000),
//	              new EmployeeModel("Sara", "Sales", 3000),
//	              new EmployeeModel("Andy", "Sales", 3000),
//	              new EmployeeModel("Charlie", "Sales", 2500),
//	              new EmployeeModel("Jim", "Sales", 4500),
//	              new EmployeeModel("Sam", "Sales", 2500)
//	      );
//	  }
	public static void main(String[] args){

		ApplicationContext context = SpringApplication.run(SpringbootApplication.class, args);
		
//		EmployeeModelRepository employeeModelRepository = context.getBean(EmployeeModelRepository.class);
		
//		employeeModelRepository.saveAll(createEmployees());
		
//		Page<EmployeeModel> page = null;
//		Pageable pageable = PageRequest.of(0, 6,Sort.by("salary"));
//		
//		while(true) {
//			page = employeeModelRepository.findByDept("Sales", pageable);
//			int numberOfElements = page.getNumberOfElements();
//			System.out.println("Number of elements" + numberOfElements);
//			
//			int size = page.getSize();
//			System.out.println("Size of the page is" +size);
//			
//			long totalElements = page.getTotalElements();
//			System.out.println("Total Elements = "+totalElements);
//			
//			long totalPages = page.getTotalPages();
//			System.out.println("Total Pages = "+totalPages);
//			
//			List<EmployeeModel> employeeModels = page.getContent();
//			employeeModels.forEach(System.err::println);
//			if(!page.hasNext())
//			{
//				break;
//			}
//			pageable = page.nextPageable();
//			
//		}
		
//		EmployeeDAO employeeDAO = context.getBean(EmployeeDAO.class);
//		Pageable pageable = PageRequest.of(0, size)
		
		
		Arrays.asList(context.getBeanDefinitionNames()).forEach(System.out::println);
		EmployeeService employeeService = context.getBean(EmployeeService.class);
		OfficeService officeService = context.getBean(OfficeService.class);
		CustomerService customerService = context.getBean(CustomerService.class);
		PaymentService paymentService = context.getBean(PaymentService.class);

		System.out.println(employeeService!=null);
		

//		Office office = new Office("9","VSKP","9232389793","aa12","ashgmailcom","AP","India","hah878","Ind");
//		String res = officeService.deleteOffice("9");
//		System.out.println("delete result "+res);
//		Optional<Office> res = officeService.updateOffice("8", office);
//		System.out.println(res);
//		officeService.getOfficeById("9");
//		Optional<List<Office>> res = officeService.getOffices();
//		if(res.isPresent())
//		{
//			res.get().forEach(System.out::println);
//		}
//		else
//		{
//			System.out.println("No records found");
//		}
//		officeService.officeExistsById("9");
		
		

//		Customer customer = new Customer(500,"re","mo","li","342324","sda","asda","ds","fef","4rsfe","df",1612,23);
//		String res = customerService.deleteCustomer("501");
//		System.out.println(res);
//		customerService.getCustomerById("500");
//		Optional<List<Customer>> res = customerService.getCustomers();
//		if(res.isPresent())
//		{
//			res.get().forEach(System.out::println);
//		}
//		else
//		{
//			System.out.println("No records found");
//		}
		
		
//		Order order = new Order(10501,"2334-2-21","1232-3-12","4343-3-12","lol","jkajs",119);
//		Optional<Order> res = orderService.updateOrder("10500", order);
//		System.out.println(res);
//		String res = orderService.deleteOrder("10501");
//		System.out.println(res);
//		orderService.getOrderById("10425");
//		Optional<List<Order>> res = orderService.getOrders();
//		if(res.isPresent())
//		{
//			res.get().forEach(System.out::println);
//		}
//		else
//		{
//			System.out.println("No records found");
//		}
		
		
//		ProductLine productLine = new ProductLine("Cab", "oboin", "asda", "sda");
//		Optional<ProductLine> res = productLineService.updateProductLine("Bike", productLine);
//		System.out.println(res);
//		String res = productLineService.deleteProductLine("Cab");
//		System.out.println(res);
//		productLineService.getProductLineById("Trains");
//		Optional<List<ProductLine>> res = productLineService.getProductLines();
//		if(res.isPresent())
//		{
//			res.get().forEach(System.out::println);
//		}
//		else
//		{
//			System.out.println("No records found");
//		}
		Office office = new Office();
		office.setOfficeCode("781244");
		office.setCity("sef");
		office.setPhone("asfsaf");
		office.setAddressLine1("afsqwdq");
		office.setAddressLine2("ssads");
		office.setState("fwfasd");
		office.setCountry("acssd");
		office.setPostalCode("dwada");
		office.setTerritory("dsjh");
//		boolean result1 = officeService.addOffice(office);
//		if(result1)
//		{
//			System.out.println("record successfull");
//			
//		}
//		else
//		{	
//			System.out.println("problem");
//		}
//		
		Employee employee = new Employee();
		employee.setEmail("sdfaqwdwesfr");
		employee.setFirstName("ada");
		employee.setLastName("dada");
		employee.setJobTitle("asda");
		employee.setExtension("dasd");
		employee.setOfficeCode(office);	
		employee.setReportsTo(1002);
		employee.setEmployeeNumber(23783);
		
		boolean result = employeeService.addEmployee(employee);
		if(result)
		{
			System.out.println("record successfull");
			
		}
		else
		{	
			System.out.println("problem");
		}
		
//		Customer customer = new Customer();
//		customer.setCustomerName("Mouli");
//		customer.setContactFirstName("M");
//		customer.setContactLastName("Mou");
//		customer.setPhone("8942");
//		customer.setAddressLine1("sfd");
//		customer.setAddressLine2("sas");
//		customer.setCity("vsk");
//		customer.setState("ap");
//		customer.setPostalCode("skj");
//		customer.setCountry("ind");
//		customer.setSalesRepEmployeeNumber(1504);
//		customer.setCreditLimit(2);
//		customer.setCustomerNumber(2142442);
//		boolean result1 = customerService.addCustomer(customer);
//		if(result1)
//		{
//			System.out.println("record successfull");
//			
//		}
//		else
//		{	
//			System.out.println("problem");
//		}
//		Payment payment = new Payment();
//		payment.setAmount(3);
//		payment.setCheckNumber("HJASD7");
//		payment.setCustomerNumber(customer);
//		payment.setPaymentDate("2019-03-03");
//		
//		boolean result2 = paymentService.addPayment(payment);
//		if(result2)
//		{
//			System.out.println("record successfull");
//			
//		}
//		else
//		{	
//			System.out.println("problem");
//		}
		
		

//		boolean result = officeService.addOffice(office);
//		if(result)
//		{
//			System.out.println("record successfull");
//			
//		}
//		else
//		{	
//			System.out.println("problem");
//		}
		
//		System.out.println(employeeService.findTopByOrderByJobTitleDesc());
//		Optional<List<Employee>> res = employeeService.findByOfficeCode("1");
//		res.get().forEach(System.out::println);
		
//		Optional<List<Employee>> res1 = employeeService.findFirst2ByOfficeCode("1");
//		res1.get().forEach(System.out::println);
		
//		Optional<List<Employee>> res2 = employeeService.findByFirstNameLike("G%");
//		res2.get().forEach(System.out::println);
		
//		int res3 = employeeService.countByOfficeCode("2");
//		System.out.println(res3);
		
//		int res4 = employeeService.countByOfficeCode();
//		System.out.println(res4);
		
//		employeeService.method().get().forEach(o->{
//			System.out.println(o[0]+"               "+o[1]);
//		});
		
//		employeeService.method1().forEach(o->{
//			System.out.println(o.getCode()+"     "+o.getCodeCount());
//		});
//		
//		employeeService.employeeMap().forEach(e->{
//			e.forEach((k,v)-> {
//				System.out.println(k+"     map    "+v);
//			});
//		});
	}

}
