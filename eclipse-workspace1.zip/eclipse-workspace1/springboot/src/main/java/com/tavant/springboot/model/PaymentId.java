package com.tavant.springboot.model;

import java.io.Serializable;

import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PaymentId implements Serializable {
//	@ManyToOne
//	@JoinColumn(name="customerNumber")
	private Customer customerNumber;
	private String checkNumber;
}
