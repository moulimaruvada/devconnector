package com.tavant.springboot.exception;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public class InvalidDepIdException extends Exception {
	
	public InvalidDepIdException(String msg) {
		super(msg);
		
	}	

	@Override	
		public String toString() {
		
			return super.toString()+ this.getMessage();
	}

	

}
