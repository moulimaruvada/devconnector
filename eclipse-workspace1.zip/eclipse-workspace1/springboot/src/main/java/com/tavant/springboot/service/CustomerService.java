package com.tavant.springboot.service;

import java.util.List;
import java.util.Optional;

import com.tavant.springboot.model.Customer;

public interface CustomerService {

	public boolean addCustomer(Customer customer);
	public Optional<Customer> updateCustomer(String custId,Customer customer);
	public String deleteCustomer(String custId);
	public Optional<Customer> getCustomerById(String custId);
	public Optional<List<Customer>> getCustomers();
	
	public boolean customerExistsById(String custId);
}
