package com.tavant.springboot.service;

import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tavant.springboot.dao.EmployeeDAO;
import com.tavant.springboot.model.Employee;
import com.tavant.springboot.model.ICountData;
@Service("employeeService")	
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeDAO employeeDAO;
	
	@Override
	public boolean addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		Employee employee = employeeDAO.save(emp);
		return employee!=null;
	}

	@Override
	public Optional<Employee> updateEmployee(String empId, Employee employee) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteEmployee(String empId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<Employee> getEmployeeById(int empId) {
		// TODO Auto-generated method stub
		return employeeDAO.findById(empId);
	}

	@Override
	public Optional<List<Employee>> getEmployees() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean employeeExistsById(int empId) {
		// TODO Auto-generated method stub
		return employeeDAO.existsById(empId);
	}

	@Override
	public Employee findTopByOrderByJobTitleDesc() {
		// TODO Auto-generated method stub
		return employeeDAO.findTopByOrderByJobTitleDesc();
	}

	@Override
	public Optional<List<Employee>> findByOfficeCode(String officeCode) {
		// TODO Auto-generated method stub
		return employeeDAO.findByOfficeCode(officeCode);
	}

	@Override
	public Optional<List<Employee>> findFirst2ByOfficeCode(String officeCode) {
		// TODO Auto-generated method stub
		return employeeDAO.findFirst2ByOfficeCode(officeCode);
	}

	@Override
	public Optional<List<Employee>> findByFirstNameLike(String firstName) {
		// TODO Auto-generated method stub
		return employeeDAO.findByFirstNameLike(firstName);
	}

//	@Override
//	public int countByOfficeCode(String off) {
//		// TODO Auto-generated method sstub
//		return employeeDAO.countByOfficeCode(off);
//	}

	@Override
	public int countByOfficeCode() {
		// TODO Auto-generated method stub
		return employeeDAO.countByOfficeCode();
	}

	@Override
	public Optional<List<Object[]>> method() {
		// TODO Auto-generated method stub
		return employeeDAO.method();
	}

	@Override
	public List<ICountData> method1() {
		// TODO Auto-generated method stub
		return employeeDAO.method1();
	}

	@Override
	public List<HashMap<String, Object>> employeeMap() {
		// TODO Auto-generated method stub
		return employeeDAO.employeeMap();
	}
	
	
}
