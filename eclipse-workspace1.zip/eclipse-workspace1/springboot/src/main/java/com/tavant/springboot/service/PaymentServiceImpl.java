package com.tavant.springboot.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tavant.springboot.dao.PaymentDAO;
import com.tavant.springboot.model.Employee;
import com.tavant.springboot.model.Payment;

@Service("paymentService")
public class PaymentServiceImpl implements PaymentService {

	@Autowired
	PaymentDAO paymentDAO;
		
	@Override
	public boolean addPayment(Payment pay) {
		// TODO Auto-generated method stub
		Payment payment = paymentDAO.save(pay);
		return payment!=null;
	}

	@Override
	public Optional<Payment> updatePayment(String payId, Payment payment) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deletePayment(String payId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<Payment> getPaymentById(String payId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<List<Payment>> getPayments() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean PaymentExistsById(String payId) {
		// TODO Auto-generated method stub
		return false;
	}

}
