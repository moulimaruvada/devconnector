package com.tavant.springboot.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Length;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "employees")
public class Employee {


			@Id
			private Integer employeeNumber;
//			@Column(name="fname")
			private String lastName;
			private String firstName;
//			@Transient
			private String extension;
//			@Size(max=20)
			private String email;
			@ManyToOne
			private Office officeCode;
			private Integer reportsTo;
			private String jobTitle;
			
	

}
