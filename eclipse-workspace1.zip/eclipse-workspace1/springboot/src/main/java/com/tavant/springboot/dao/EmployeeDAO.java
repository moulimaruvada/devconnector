package com.tavant.springboot.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.tavant.springboot.model.Employee;
import com.tavant.springboot.model.ICountData;

@Repository
public interface EmployeeDAO extends JpaRepository<Employee, Integer>{


	public Employee findTopByOrderByJobTitleDesc();
	public Employee findTopByOrderByJobTitleAsc();
	public Optional<List<Employee>> findTop3ByOrderByJobTitleDesc();
	public Optional<List<Employee>> findTop3ByOrderByJobTitleAsc();
	public Optional<List<Employee>> findByOfficeCode(String officeCode);
	public Optional<List<Employee>> findFirst2ByOfficeCode(String officeCode);
	public Optional<List<Employee>> findByFirstNameLike(String firstName);
//	public int countByOfficeCode(String off);
	@Query("select count(officeCode) from Employee")
	public int countByOfficeCode();
	@Query("select officeCode as code, count(officeCode) as Count from Employee group by officeCode"
			+ " order by officeCode desc")
	public Optional<List<Object[]>> method();
//	@Query("select new com.tavant.springboot.model.ICountData(e.officeCode, COUNT(e.officeCode)) from Employee e group by e.officeCode order by "+
//			"e.officeCode desc")
//	public List<ICountData> method1();
	@Query("select e.officeCode as code, COUNT(e.officeCode) as codeCount from Employee e group by e.officeCode order by "+
			"e.officeCode desc")
	public List<ICountData> method1();
	
	@Query("select new map (e.officeCode, COUNT(e.officeCode)) from Employee e group by e.officeCode order by "+
			"e.officeCode desc")
	public List<HashMap<String, Object>> employeeMap();
	
	public Page<Employee> findByOfficeCode(String officecode,org.springframework.data.domain.Pageable pageable);
	
}
