package com.tavant.springboot.model;

import lombok.AllArgsConstructor;
import lombok.Data;


public interface ICountData {

	public String getCode();
	public Long getCodeCount();
}
