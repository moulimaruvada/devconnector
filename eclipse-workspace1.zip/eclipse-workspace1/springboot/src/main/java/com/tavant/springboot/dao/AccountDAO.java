package com.tavant.springboot.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tavant.springboot.model.Account;

public interface AccountDAO extends JpaRepository<Account, String> {

}
