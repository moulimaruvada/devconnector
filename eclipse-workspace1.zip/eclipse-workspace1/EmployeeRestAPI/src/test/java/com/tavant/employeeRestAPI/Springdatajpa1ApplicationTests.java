package com.tavant.employeeRestAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springdatajpa1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
