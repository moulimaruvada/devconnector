package com.tavant.employeerestapi.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tavant.employeerestapi.exception.EmployeeNotFoundException;
import com.tavant.employeerestapi.exception.EmptyObjectException;
import com.tavant.employeerestapi.exception.NoDataFoundException;

import com.tavant.employeerestapi.model.OrderDetail;
import com.tavant.employeerestapi.model.Orders;
import com.tavant.employeerestapi.model.Payment;
import com.tavant.employeerestapi.repository.OrderDetailRepository;
import com.tavant.employeerestapi.repository.OrderRepository;
import com.tavant.employeerestapi.repository.PaymentRepository;

@RestController
@RequestMapping("/api/payment")
public class PaymentController {
	
	@Autowired
	PaymentRepository paymentRepository;
	@GetMapping
	public String getPayment() {
		return "payment";
	}
	
	@GetMapping("/all")
	public ResponseEntity<?> getAllPayment() throws NoDataFoundException, EmployeeNotFoundException 
	{
		Optional<List<Payment>> optional = Optional.of(paymentRepository.findAll());
		if(optional.isEmpty())
		{
			throw new EmployeeNotFoundException("record not found");
			
		}
		else {
			return ResponseEntity.ok(optional.get());	
		}

	}

	@GetMapping("/{customerNumber}")
	public ResponseEntity<?> getPaymentById(@PathVariable("customerNumber") Integer id) throws EmployeeNotFoundException {
		Optional<Payment> optional = paymentRepository.findById(id);
		if(optional.isPresent()) 	{
			return ResponseEntity.ok(optional.get());
		}
		else {
			throw new EmployeeNotFoundException("record not found");
		}
		
	}
	
	@PostMapping 
	public Payment addPayment(@RequestBody @Valid Payment payment) throws EmptyObjectException {
//		if(payment.getCustomerNumber() == null)
//		{
//			throw new EmptyObjectException("Provide Employee Object");
//		}
		return paymentRepository.save(payment);
	}
	
	@DeleteMapping("/del/{customerNumber}")
	public String deletePayment(@PathVariable("customerNumber") Integer id) throws EmployeeNotFoundException {
		
		Payment payment = paymentRepository.findById(id).orElseThrow(()-> new EmployeeNotFoundException("Details not found"));

			 paymentRepository.delete(payment);
			 
		return "Deleted";
		 
		
		
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<Payment> updatePayment(@PathVariable(value = "id") Integer Id, @Valid @RequestBody Payment paymentDetails) throws EmployeeNotFoundException {
	 Payment payment = paymentRepository.findById(Id).orElseThrow(() -> new EmployeeNotFoundException("Not found "));

	 payment.setCheckNumber(paymentDetails.getCheckNumber());
	 payment.setPaymentDate(paymentDetails.getPaymentDate());
	 payment.setAmount(paymentDetails.getAmount());
	 
	 
	 final Payment updatedPayment = paymentRepository.save(paymentDetails);
	 return ResponseEntity.ok(updatedPayment);
	}
	
	
}

