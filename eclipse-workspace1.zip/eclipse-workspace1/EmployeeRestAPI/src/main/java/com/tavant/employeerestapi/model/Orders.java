package com.tavant.employeerestapi.model;




import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="orders")
public class Orders {

	
	@Id
	private Integer orderNumber;
	@NotBlank(message="order date should not be blank")
	private String orderDate;
	@NotBlank(message="required date should not be blank")
	private String requiredDate;
	private String shippedDate;
	private String status;
	private String comments;
	private Integer customerNumber;
	
}
