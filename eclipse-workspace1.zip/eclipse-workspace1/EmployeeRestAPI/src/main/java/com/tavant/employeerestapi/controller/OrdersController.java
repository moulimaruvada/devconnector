package com.tavant.employeerestapi.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tavant.employeerestapi.exception.EmployeeNotFoundException;
import com.tavant.employeerestapi.exception.EmptyObjectException;
import com.tavant.employeerestapi.exception.NoDataFoundException;

import com.tavant.employeerestapi.model.OrderDetail;
import com.tavant.employeerestapi.model.Orders;
import com.tavant.employeerestapi.repository.OrderDetailRepository;
import com.tavant.employeerestapi.repository.OrderRepository;

@RestController
@RequestMapping("/api/orders")
public class OrdersController {
	
	@Autowired
	OrderRepository orderRepository;
	@GetMapping
	public String getOrders() {
		return "Orders";
	}
	
	@GetMapping("/all")
	public ResponseEntity<?> getAllOrders() throws NoDataFoundException, EmployeeNotFoundException 
	{
		Optional<List<Orders>> optional = Optional.of(orderRepository.findAll());
		if(optional.isEmpty())
		{
			throw new EmployeeNotFoundException("record not found");
			
		}
		else {
			return ResponseEntity.ok(optional.get());	
		}

	}

	@GetMapping("/{orderNumber}")
	public ResponseEntity<?> getOrderById(@PathVariable("orderNumber") Integer id) throws EmployeeNotFoundException {
		Optional<Orders> optional = orderRepository.findById(id);
		if(optional.isPresent()) 	{
			return ResponseEntity.ok(optional.get());
		}
		else {
			throw new EmployeeNotFoundException("record not found");
		}
		
	}
	
	@PostMapping 
	public Orders addOrder(@RequestBody @Valid Orders order) throws EmptyObjectException {
//		if(order.getOrderNumber() == null)
//		{
//			throw new EmptyObjectException("Provide Employee Object");
//		}
		return orderRepository.save(order);
	}
	
	
	@DeleteMapping("/del/{orderNumber}")
	public String deleteOrder(@PathVariable("orderNumber") Integer id) throws EmployeeNotFoundException {
		
		Orders orders = orderRepository.findById(id).orElseThrow(()-> new EmployeeNotFoundException("Details not found"));

			 orderRepository.delete(orders);
			 
		return "Deleted";
		 
		
		
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<Orders> updateOrder(@PathVariable(value = "id") Integer Id, @Valid @RequestBody Orders ordersDetails) throws EmployeeNotFoundException {
	 Orders orders = orderRepository.findById(Id).orElseThrow(() -> new EmployeeNotFoundException("Not found "));

	 orders.setCustomerNumber(ordersDetails.getCustomerNumber());
	 orders.setRequiredDate(ordersDetails.getRequiredDate());
	 orders.setOrderDate(ordersDetails.getOrderDate());
	 orders.setShippedDate(ordersDetails.getShippedDate());
	 orders.setComments(ordersDetails.getComments());
	 orders.setStatus(ordersDetails.getStatus());
	 
	 final Orders updatedOrders = orderRepository.save(ordersDetails);
	 return ResponseEntity.ok(updatedOrders);
	}
}

