package com.tavant.employeerestapi.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Length;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "employees")
public class Employee {


			@Id
			private Integer employeeNumber;
//			@Column(name="fname")
			@NotBlank(message="lastName should not be blank")
			private String lastName;
			@NotBlank(message="firstName should not be blank")
			private String firstName;
//			@Transient
			@NotBlank(message="extension should not be blank")
			private String extension;
//			@Size(max=20)
			@NotBlank(message="email should not be blank")
			private String email;
//			@ManyToOne
			@NotBlank(message="office Code should not be blank")
			@Max(123)
			private String officeCode;
			private Integer reportsTo;
			private String jobTitle;
			
	

}
