package com.tavant.employeerestapi.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tavant.employeerestapi.exception.EmployeeNotFoundException;
import com.tavant.employeerestapi.exception.EmptyObjectException;
import com.tavant.employeerestapi.exception.NoDataFoundException;
import com.tavant.employeerestapi.model.Customer;
import com.tavant.employeerestapi.model.OrderDetail;

import com.tavant.employeerestapi.repository.OrderDetailRepository;

@RestController
@RequestMapping("/api/orderdetail")
public class OrderDetailController {
	
	@Autowired
	OrderDetailRepository orderDetailRepository;
	@GetMapping
	public String getOrderDetail() {
		return "OrderDetail";
	}
	
	@GetMapping("/all")
	public ResponseEntity<?> getAllOrderDetail() throws NoDataFoundException, EmployeeNotFoundException 
	{
		Optional<List<OrderDetail>> optional = Optional.of(orderDetailRepository.findAll());
		if(optional.isEmpty())
		{
			throw new EmployeeNotFoundException("record not found");
			
		}
		else {
			return ResponseEntity.ok(optional.get());	
		}

	}

	@GetMapping("/{orderNumber}")
	public ResponseEntity<?> getOrderDetailById(@PathVariable("orderNumber") Integer id) throws EmployeeNotFoundException {
		Optional<OrderDetail> optional = orderDetailRepository.findById(id);
		if(optional.isPresent()) 	{
			return ResponseEntity.ok(optional.get());
		}
		else {
			throw new EmployeeNotFoundException("record not found");
		}
		
	}
	
	@PostMapping 
	public OrderDetail addOrderDetail(@RequestBody @Valid OrderDetail orderDetail) throws EmptyObjectException {
//		if(orderDetail.getOrderNumber() == null)
//		{
//			throw new EmptyObjectException("Provide Employee Object");
//		}
		return orderDetailRepository.save(orderDetail);
	}
	
	@DeleteMapping("/del/{orderNumber}")
	public String deleteOrderDetail(@PathVariable("orderNumber") Integer id) throws EmployeeNotFoundException {
		
		OrderDetail orderDetail = orderDetailRepository.findById(id).orElseThrow(()-> new EmployeeNotFoundException("Details not found"));

			 orderDetailRepository.delete(orderDetail);
			 
		return "Deleted";
		 
		
		
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<OrderDetail> updateOrderDetail(@PathVariable(value = "id") Integer Id, @Valid @RequestBody OrderDetail OrderDetailDetails) throws EmployeeNotFoundException {
	 OrderDetail orderDetail = orderDetailRepository.findById(Id).orElseThrow(() -> new EmployeeNotFoundException("Not found "));

	 orderDetail.setOrderLineNumber(OrderDetailDetails.getOrderLineNumber());
	 orderDetail.setPriceEach(OrderDetailDetails.getPriceEach());
	 orderDetail.setProductCode(OrderDetailDetails.getProductCode());
	 orderDetail.setQuantityOrdered(OrderDetailDetails.getQuantityOrdered());
	 
	 final OrderDetail updatedOrderDetail = orderDetailRepository.save(orderDetail);
	 return ResponseEntity.ok(updatedOrderDetail);
	}
}

