package com.tavant.employeerestapi.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.apache.catalina.connector.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tavant.employeerestapi.exception.EmployeeNotFoundException;
import com.tavant.employeerestapi.exception.EmptyObjectException;
import com.tavant.employeerestapi.exception.NoDataFoundException;
import com.tavant.employeerestapi.model.Employee;
import com.tavant.employeerestapi.repository.EmployeeRepository;

// to perform the work of controller if we are using spring mvc
//then we will use @controller
// but here we are using rest so
// we should use @RestController
// this annotation is introduced from spring mvc version 4x
// before spring 3.0 it was a combination of 
//@ResponseEntity and @controller
// in 4.0 they form @RestController
// when we will deal with any rest application there
// we have to send the response
// will be a JSON, HTML, XML, or any file
// whenever we have to share the data there we have to mark @Responseentity
// then what they have done instead of marketing it on each and every method
// they came up with a solution @RestController

@RestController
@RequestMapping("/api/employee")
public class EmployeeController {
	
	@Autowired
	EmployeeRepository employeeRepository;
	@GetMapping
	public String getEmployee() {
		return "hello";
	}
	
	@GetMapping("/all")
	public ResponseEntity<?> getAllEmployees() throws NoDataFoundException, EmployeeNotFoundException 
	{
		Optional<List<Employee>> optional = Optional.of(employeeRepository.findAll());
		//get all without exception
//		return employeeRepository.findAll();
		if(optional.isEmpty())
		{
			throw new EmployeeNotFoundException("record not found");
			
		}
		else {
			return ResponseEntity.ok(optional.get());	
		}
//		if(employeeRepository.findAll().isEmpty())
//		{
//			throw new NoDataFoundException("No records found") ;
//		}
////		return Optional.ofNullable(employeeRepository.findAll()).orElseThrow(()->new NoDataFoundException("No records found"));
//		return employeeRepository.findAll();

	}

	@GetMapping("/{employeeNumber}")
	public ResponseEntity<?> getEmployeeById(@PathVariable("employeeNumber") Integer id) throws EmployeeNotFoundException {
		Optional<Employee> optional = employeeRepository.findById(id);
		//get by id without exception
		//		return employeeRepository.findById(id).get();
//		return employeeRepository.findById(id).orElseThrow(()-> new EmployeeNotFoundException("Employee Not found"));
		if(optional.isPresent()) 	{
			return ResponseEntity.ok(optional.get());
		}
		else {
			throw new EmployeeNotFoundException("record not found");
		}
		
	}
	
	@PostMapping //transforming json to java object
	// jackson api will take care implicitly
	public Employee addEmployee(@RequestBody @Valid Employee employee) throws EmptyObjectException {
//		if(employee.getEmployeeNumber() == null )
//		{
//			throw new EmptyObjectException("Provide Employee Object");
//		}
		return employeeRepository.save(employee);
	}
	
	@DeleteMapping("/del/{employeeNumber}")
	public String deleteEmployee(@PathVariable("employeeNumber") Integer id) throws EmployeeNotFoundException {
		
		Employee employee = employeeRepository.findById(id).orElseThrow(()-> new EmployeeNotFoundException("Details not found"));

			 employeeRepository.delete(employee);
			 
		return "Deleted";
		 
		
		
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<Employee> updateEmployee(@PathVariable(value = "id") Integer Id, @Valid @RequestBody Employee EmployeeDetails) throws EmployeeNotFoundException {
	 Employee employee = employeeRepository.findById(Id).orElseThrow(() -> new EmployeeNotFoundException("Not found "));

	 employee.setFirstName(EmployeeDetails.getFirstName());
	 employee.setLastName(EmployeeDetails.getLastName());
	 employee.setEmail(EmployeeDetails.getEmail());
	 employee.setExtension(EmployeeDetails.getExtension());
	 employee.setJobTitle(EmployeeDetails.getJobTitle());
	 employee.setOfficeCode(EmployeeDetails.getOfficeCode());
	 employee.setReportsTo(EmployeeDetails.getReportsTo());
	 
	 final Employee updatedEmployee = employeeRepository.save(employee);
	 return ResponseEntity.ok(updatedEmployee);
	}

	
}
