package com.tavant.employeerestapi.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tavant.employeerestapi.exception.EmployeeNotFoundException;
import com.tavant.employeerestapi.exception.EmptyObjectException;
import com.tavant.employeerestapi.exception.NoDataFoundException;
import com.tavant.employeerestapi.model.Customer;
import com.tavant.employeerestapi.model.Employee;
import com.tavant.employeerestapi.repository.CustomerRepository;
import com.tavant.employeerestapi.repository.EmployeeRepository;

@RestController
@RequestMapping("/api/customer")
public class CustomerController {
	
	@Autowired
	CustomerRepository customerRepository;
	@GetMapping
	public String getCustomer() {
		return "Customer";
	}
	
	@GetMapping("/all")
	public ResponseEntity<?> getAllCustomers() throws NoDataFoundException, EmployeeNotFoundException 
	{
		Optional<List<Customer>> optional = Optional.of(customerRepository.findAll());
		if(optional.isEmpty())
		{
			throw new EmployeeNotFoundException("record not found");
			
		}
		else {
			return ResponseEntity.ok(optional.get());	
		}

	}

	@GetMapping("/{customerNumber}")
	public ResponseEntity<?> getCustomerById(@PathVariable("customerNumber") Integer id) throws EmployeeNotFoundException {
		Optional<Customer> optional = customerRepository.findById(id);
		if(optional.isPresent()) 	{
			return ResponseEntity.ok(optional.get());
		}
		else {
			throw new EmployeeNotFoundException("record not found");
		}
		
	}
	
	@PostMapping 
	public Customer addCustomer(@RequestBody @Valid Customer customer) throws EmptyObjectException {
//		if(customer.getCustomerNumber() == null )
//		{
//			throw new EmptyObjectException("Provide Employee Object");
//		}
		return customerRepository.save(customer);
	}
	
	@DeleteMapping("/del/{customerNumber}")
	public String deleteCustomer(@PathVariable("customerNumber") Integer id) throws EmployeeNotFoundException {
		
		Customer customer = customerRepository.findById(id).orElseThrow(()-> new EmployeeNotFoundException("Details not found"));

			 customerRepository.delete(customer);
			 
		return "Deleted";
		 
		
		
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<Customer> updateCustomer(@PathVariable(value = "id") Integer Id, @Valid @RequestBody Customer CustomerDetails) throws EmployeeNotFoundException {
	 Customer customer = customerRepository.findById(Id).orElseThrow(() -> new EmployeeNotFoundException("Not found "));

	 customer.setCustomerName(CustomerDetails.getCustomerName());
	 customer.setAddressLine1(CustomerDetails.getAddressLine1());
	 customer.setAddressLine2(CustomerDetails.getAddressLine2());
	 customer.setContactFirstName(CustomerDetails.getContactFirstName());
	 customer.setContactLastName(CustomerDetails.getContactLastName());
	 customer.setPhone(CustomerDetails.getPhone());
	 customer.setCity(CustomerDetails.getCity());
	 customer.setCountry(CustomerDetails.getCountry());
	 customer.setCreditLimit(CustomerDetails.getCreditLimit());
	 customer.setState(CustomerDetails.getState());
	 customer.setSalesRepEmployeeNumber(CustomerDetails.getSalesRepEmployeeNumber());
	 customer.setPostalCode(CustomerDetails.getPostalCode());
	 
	 final Customer updatedCustomer = customerRepository.save(customer);
	 return ResponseEntity.ok(updatedCustomer);
	}
}

