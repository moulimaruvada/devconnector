package com.tavant.employeerestapi.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "customers")
public class Customer {

	@Id
	private Integer customerNumber;
	@NotBlank(message="customer name should not be blank")
	private String customerName;

	private String contactLastName;
	private String contactFirstName;
	@NotBlank(message="phone number should not be blank")
	private String phone;
	private String addressLine1;
	private String addressLine2;
	private String city;
	private String state;
	private String postalCode;
	private String country;
	private int salesRepEmployeeNumber;
	private float creditLimit;
//	@OneToMany(mappedBy="customerNumber")
//	private List<Payment> paymentList;
	
	
}
