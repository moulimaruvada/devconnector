package com.tavant.employeerestapi.exception;

public class InvalidLocIdException extends Exception {
	
	public InvalidLocIdException(String msg) {
		super(msg);
		
	}	

	@Override	
		public String toString() {
		
			return super.toString()+ this.getMessage();
	}


}
