package com.tavant.employeerestapi.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="orderdetails")
public class OrderDetail {

	@Id
	private Integer orderNumber;
	@NotBlank(message="product code should not be blank")
	private String productCode;
	@NotNull(message="quantity ordered should not be blank")
	private Integer quantityOrdered;
	private float priceEach;
	private Integer orderLineNumber;
	
}
