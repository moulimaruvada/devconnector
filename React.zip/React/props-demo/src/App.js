import logo from "./logo.svg";
import "./App.css";
import ChildComponent from "./ChildComponent";

function App() {
  let data1 = "maruvada";
  return (
    <div className="App">
      <ChildComponent name="mouli" data1={data1}></ChildComponent>
    </div>
  );
}

export default App;
