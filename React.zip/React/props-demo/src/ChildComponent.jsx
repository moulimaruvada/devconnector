import React from "react";
import PropTypes from "prop-types";
import ChildComponent2 from "./ChildComponent2";

const ChildComponent = ({ name, data1 }) => {
  return (
    <div>
      <h1>Hello from {name} </h1>
      <ChildComponent2 name={name} data1={data1}></ChildComponent2>
    </div>
  );
};

ChildComponent.propTypes = {};

export default ChildComponent;
