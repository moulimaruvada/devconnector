import React from "react";
import PropTypes from "prop-types";

const ChildComponent2 = (props) => {
  return (
    <div>
      {props.name} {props.data1}
    </div>
  );
};

export default ChildComponent2;
