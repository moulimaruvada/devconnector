import React, { Component } from "react";

export default class hello extends Component {
  render() {
    return <div></div>;
  }
}
