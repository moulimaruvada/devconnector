async function f() {
  // return 1;
  //   return Promise.resolve(123);
  //   return Promise.reject(12345);

  console.log("Function started");
  let promise = await new Promise((resolve, reject) => {
    setTimeout(() => {
      resolve("Completed");
    }, 2000);
  });
  let result = await promise;
  console.log("After the promise");
  return promise;
}

f()
  .then((data) => console.log(data))
  .catch((data) => console.log("Data from catch, which is rejected " + data));
