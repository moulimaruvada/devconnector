import api from "./api";

const setAuthToken = (token) => {
  console.log(" jwt Token " + token);
  if (token) {
    api.defaults.headers.common["x-auth-token"] = token;
    localStorage.setItem("token", token);
    // what is the use of local storage will be accessible to only to its domain contents/

    //cookies vs localstorage
  } else {
    delete api.defaults.headers.common["x-auth-token"];
    localStorage.removeItem("token");
  }
};

export default setAuthToken;
