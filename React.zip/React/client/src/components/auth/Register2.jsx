//class based components
//it will extend to a component class
//then all features of component class and life cycle methods will be associated with your class
//if pricessing is expected then we should use class based component till react version 16.8
//it is bulky

//a functional based component
//it is used only for presentation work (no processing)(till 16.8)
//but from 16.9 onwards we can use  a functional based component for any kind of processing of ur application data

//hooks allow you to use local state and other react feature without writing a class

//then usage perspective functional based components become light weight compared with class based components
import React, { useState } from "react";
import axios from "axios";
import classnames from "classnames";
import { useHistory } from "react-router-dom";

const Register2 = (props) => {
  const [formData, setformData] = useState({
    name: "",
    email: "",
    password: "",
    password2: "",
  });

  const [errors, setErrors] = useState({});

  let history = useHistory();

  const { name, email, password, password2 } = formData;

  const handleChange = async (e) => {
    await setformData({ ...formData, [e.target.name]: e.target.value });
    //console.log(this.state.name);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Form Submitted");
    //console.log(this.state);
    if (password !== password2) {
      history.push("/alert");
      //   alert(err.response.data);
    }

    const newUser = formData;
    //Axios is a library that helps us make http requests to external resources
    axios
      .post("/api/users/register", newUser)
      //if success
      .then((res) => {
        console.log(JSON.stringify(res));
        //props==> properties (its an built in)==> history ==> push ==> will redirect ==> login
        history.push("/login");
      })
      //if failure
      .catch((err) => {
        //store the error data to setErros
        setErrors(err.response.data);
        console.log(JSON.stringify(err.response.data));
      });
  };
  return (
    <div className="register">
      <div className="container">
        <div className="row">
          <div className="col-md-8 m-auto">
            <h1 className="display-4 text-center">Sign Up</h1>
            <p className="lead text-center">Create your DevConnector account</p>
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <input
                  type="text"
                  className={classnames("form-control form-control-lg", {
                    "is-invalid": errors.name,
                  })}
                  placeholder="Name"
                  name="name"
                  value={name}
                  onChange={handleChange}
                  required
                />
                {/* to print the error */}
                {errors.name && (
                  <div className="d-block invalid-feedback">{errors.name}</div>
                )}
              </div>
              <div className="form-group">
                <input
                  type="email"
                  className={classnames("form-control form-control-lg", {
                    "is-invalid": errors.email,
                  })}
                  placeholder="Email Address"
                  name="email"
                  value={email}
                  onChange={handleChange}
                />
                {errors.email && (
                  <div className="d-block invalid-feedback">{errors.email}</div>
                )}
                <small className="form-text text-muted">
                  This site uses Gravatar so if you want a profile image, use a
                  Gravatar email
                </small>
              </div>
              <div className="form-group">
                <input
                  type="password"
                  className={classnames("form-control form-control-lg", {
                    "is-invalid": errors.password,
                  })}
                  placeholder="Password"
                  name="password"
                  value={password}
                  onChange={handleChange}
                />
                {errors.password && (
                  <div className="d-block invalid-feedback">
                    {errors.password}
                  </div>
                )}
              </div>
              <div className="form-group">
                <input
                  type="password"
                  className={classnames("form-control form-control-lg", {
                    "is-invalid": errors.password2,
                  })}
                  placeholder="Confirm Password"
                  name="password2"
                  value={password2}
                  onChange={handleChange}
                />
                {errors.password2 && (
                  <div className="d-block invalid-feedback">
                    {errors.password2}
                  </div>
                )}
              </div>
              <input type="submit" className="btn btn-info btn-block mt-4" />
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Register2;
