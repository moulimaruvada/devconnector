import React, { Component } from "react";

export default class Employee extends Component {
  render() {
    return <div>Hello from employee</div>;
  }
}
