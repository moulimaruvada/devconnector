import React, { useState } from "react";
import axios from "axios";
import classnames from "classnames";

const Login2 = (props) => {
  const [formData, setformData] = useState({
    email: "",
    password: "",
  });

  const [errors, setErrors] = useState({});

  const { email, password } = formData;

  const handleChange = async (e) => {
    await setformData({ ...formData, [e.target.name]: e.target.value });
    // console.log(this.state.email);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Form Submitted");
    //console.log(this.state);

    const newUser = formData;

    axios
      .post("/api/users/login", newUser)
      .then((res) => {
        console.log(JSON.stringify(res));
      })
      .catch((err) => {
        setErrors(err.response.data);
        console.log(JSON.stringify(err.response.data));
      });
  };
  return (
    <div className="login">
      <div className="container">
        <div className="row">
          <div className="col-md-8 m-auto">
            <h1 className="display-4 text-center">Log In</h1>
            <p className="lead text-center">
              Sign in to your DevConnector account
            </p>
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <input
                  type="email"
                  className={classnames("form-control form-control-lg", {
                    "is-invalid": errors.email,
                  })}
                  placeholder="Email Address"
                  name="email"
                  value={email}
                  onChange={handleChange}
                />
                {errors.email && (
                  <div className="d-block invalid-feedback">{errors.email}</div>
                )}
              </div>
              <div className="form-group">
                <input
                  type="password"
                  className={classnames("form-control form-control-lg", {
                    "is-invalid": errors.password,
                  })}
                  placeholder="Password"
                  name="password"
                  value={password}
                  onChange={handleChange}
                />
                {errors.password && (
                  <div className="d-block invalid-feedback">
                    {errors.password}
                  </div>
                )}
              </div>
              <input type="submit" className="btn btn-info btn-block mt-4" />
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login2;
