import React from "react";
import { Route, Switch } from "react-router-dom";
import Register2 from "../auth/Register2";
import Login2 from "../auth/Login2";
import Alert from "../common/Alert";
import Register3 from "../auth/Register3";
import Dashboard from "../Dashboard/Dashboard";
import Employee from "../auth/Employee";
import PrivateRoute from "./PrivateRoute";
import ProfileForms from "../profile-forms/ProfileForms";
import Login3 from "../auth/Login3";
import AddExperience from "../profile-forms/AddExperience";
import AddEducation from "../profile-forms/AddEducation";
import Profile from "../profile/Profile";
import Profiles from "../profiles/Profiles";

const Routes = (props) => {
  return (
    <section>
      <Alert />
      <Switch>
        <Route exact path="/register" component={Register3}></Route>
        <Route exact path="/login" component={Login3}></Route>
        <Route exact path="/alert" component={Alert}></Route>
        <Route exact path="/employee" component={Employee}></Route>
        <Route exact path="/profile/:id" component={Profile}></Route>
        <Route exact path="/profiles/" component={Profiles}></Route>
        <PrivateRoute
          exact
          path="/dashboard"
          component={Dashboard}
        ></PrivateRoute>
        <PrivateRoute
          exact
          path="/create-profile"
          component={ProfileForms}
        ></PrivateRoute>
        <PrivateRoute
          exact
          path="/edit-profile"
          component={ProfileForms}
        ></PrivateRoute>
        <PrivateRoute
          exact
          path="/add-experience"
          component={AddExperience}
        ></PrivateRoute>
        <PrivateRoute
          exact
          path="/add-education"
          component={AddEducation}
        ></PrivateRoute>
      </Switch>
    </section>
  );
};

export default Routes;
