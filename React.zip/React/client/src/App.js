// import logo from "./logo.svg";
import "./App.css";
import Navbar from "./components/layout/Navbar";
import Footer from "./components/layout/Footer";
import Landing from "./components/layout/Landing";
import Routes from "./components/routing/Routes";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";

//redux import
import { Provider } from "react-redux";
import store from "./redux/store";
import setAuthToken from "../src/utils/setAuthToken";
import { useEffect } from "react";
import { loadUser } from "./redux/actions/auth";
function App() {
  useEffect(() => {
    if (localStorage.token) {
      console.log("useEffect from app.js");

      setAuthToken(localStorage.getItem("token"));
    }
    store.dispatch(loadUser());
  }, []);

  return (
    <Provider store={store}>
      <div className="App">
        <Router>
          <Navbar />
          <Switch>
            <Route exact path="/" component={Landing}></Route>
            <Route component={Routes}></Route>
          </Switch>
        </Router>

        <Footer />
      </div>
    </Provider>
  );
}

export default App;
