import { createStore, applyMiddleware } from "redux";
//create the store to create the redux store
// applymiddleware : to apply the thunk

import { composeWithDevTools } from "redux-devtools-extension";
//will provide the access to ur redux devtool extension from chrome/firefox

import thunk from "redux-thunk";
import setAuthToken from "../../utils/setAuthToken";
//this is ur middleware will help u to connect to store to manipulate the contents.

import rootReducer from "../reducers";
const initialState = {};

const middleware = [thunk];

const store = createStore(
  rootReducer,
  initialState,
  composeWithDevTools(applyMiddleware(...middleware))
);

//set up a store subscription listener
// to store the users token in local storage
// initialize current state from redux store for subscription comparision

//for preventing undefined error

let currentState = store.getState();
store.subscribe(() => {
  console.log("inside the subscribe from store index.js");
  let previousState = currentState;
  currentState = store.getState();

  if (previousState.auth.token !== currentState.auth.token) {
    const token = currentState.auth.token;
    setAuthToken(token);
  }
});

export default store;
