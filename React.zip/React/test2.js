const fetch = require("node-fetch");
// fetch method is available in browser.
const showRest = async () => {
  console.log("start");
  let response = await fetch("https://jsonplaceholder.typicode.com/todos/1");
  console.log("after fetch method call");
  let result = await response.json();
  console.log(result);
  console.log("end");
};
showRest();
