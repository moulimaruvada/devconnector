import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProfileFormsRoutingModule } from './profile-forms-routing.module';
import { CreateProfileComponent } from './components/create-profile/create-profile.component';


@NgModule({
  declarations: [CreateProfileComponent],
  imports: [
    CommonModule,
    ProfileFormsRoutingModule
  ]
})
export class ProfileFormsModule { }
