import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProfilesRoutingModule } from './profiles-routing.module';
import { ProfileItemComponent } from './components/profile-item/profile-item.component';
import { ProfilesComponent } from './components/profiles/profiles.component';


@NgModule({
  declarations: [ProfileItemComponent, ProfilesComponent],
  imports: [
    CommonModule,
    ProfilesRoutingModule
  ]
})
export class ProfilesModule { }
