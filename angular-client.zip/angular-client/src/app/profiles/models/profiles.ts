export class User {
  _id: any;
  name: string;
  avatar: string;
}
export class Profiles {
  user: User;
  status: string;
  company: string;
  location: string;
  website: string;
  social: any;
  skills: string;
}
