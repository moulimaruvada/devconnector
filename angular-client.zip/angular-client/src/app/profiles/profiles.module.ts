import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProfilesRoutingModule } from './profiles-routing.module';
import { ProfilesComponent } from './components/profiles/profiles.component';
import { ProfileItemComponent } from './components/profile-item/profile-item.component';
import { httpInterceptorProviders } from '../core/interceptors';
import { AuthService } from '../auth/services/auth.service';
import { CreateProfileService } from '../profile-forms/services/create-profile.service';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [ProfilesComponent, ProfileItemComponent],
  imports: [CommonModule, HttpClientModule, ProfilesRoutingModule],
  providers: [httpInterceptorProviders, AuthService, CreateProfileService],
})
export class ProfilesModule {}
