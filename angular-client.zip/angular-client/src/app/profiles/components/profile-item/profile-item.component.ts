import { Component, Input, OnInit } from '@angular/core';
import { Register } from 'src/app/auth/models/register';
import { AuthService } from 'src/app/auth/services/auth.service';
import { CreateProfile } from 'src/app/profile-forms/models/create-profile';
import { CreateProfileService } from 'src/app/profile-forms/services/create-profile.service';
import { Profiles } from '../../models/profiles';

@Component({
  selector: 'app-profile-item',
  templateUrl: './profile-item.component.html',
  styleUrls: ['./profile-item.component.css'],
})
export class ProfileItemComponent implements OnInit {
  // profile: Profiles;
  // register: Register;

  @Input() profiles: Profiles;
  constructor() {} // private profileService: CreateProfileService private authService: AuthService,

  ngOnInit(): void {
    // this.authService.loadUser().subscribe((res) => {
    //   console.log(JSON.stringify(res));
    //   this.register = res;
    //   localStorage.setItem('users', JSON.stringify(res));
    // });
    // this.profileService.getProfileById().subscribe((res) => {
    //   console.log(JSON.stringify(res));
    //   this.profiles = res;
    //   console.log(res);
    //   console.log(this.profiles);
    //   localStorage.setItem('profiles', JSON.stringify(res));
    // });
  }
}
