import { Component, Input, OnInit } from '@angular/core';
import { Register } from 'src/app/auth/models/register';
import { AuthService } from 'src/app/auth/services/auth.service';
import { CreateProfile } from 'src/app/profile-forms/models/create-profile';
import { CreateProfileService } from 'src/app/profile-forms/services/create-profile.service';
import { Profiles } from '../../models/profiles';

@Component({
  selector: 'app-profiles',
  templateUrl: './profiles.component.html',
  styleUrls: ['./profiles.component.css'],
})
export class ProfilesComponent implements OnInit {
  // register: Register;
  profiles: Profiles[];
  constructor(
    // private authService: AuthService,
    private profileService: CreateProfileService
  ) {}

  ngOnInit(): void {
    // this.authService.loadUser().subscribe((res) => {
    //   console.log(JSON.stringify(res));
    //   this.register = res;
    //   localStorage.setItem('users', JSON.stringify(res));
    // });

    this.profileService.getProfiles().subscribe((res) => {
      console.log(JSON.stringify(res));
      this.profiles = res;
      console.log(res);
      console.log(this.profiles);
      localStorage.setItem('profiles', JSON.stringify(res));
    });
  }
}
