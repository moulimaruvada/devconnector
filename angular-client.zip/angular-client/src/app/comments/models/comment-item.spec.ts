import { CommentItem } from './comment-item';

describe('CommentItem', () => {
  it('should create an instance', () => {
    expect(new CommentItem()).toBeTruthy();
  });
});
