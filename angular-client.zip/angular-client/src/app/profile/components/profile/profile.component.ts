import { Component, OnInit } from '@angular/core';
import jwt_decode from 'jwt-decode';
import { CreateProfileService } from 'src/app/profile-forms/services/create-profile.service';
import { Profiles } from 'src/app/profiles/models/profiles';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css'],
})
export class ProfileComponent implements OnInit {
  token: any;
  data: any;
  profile: Profiles;
  id: string;
  constructor(private profileService: CreateProfileService) {}

  ngOnInit(): void {
    //confirm that the token is available or not and decode the token
    this.token = localStorage.getItem('token');
    if (this.token) {
      this.data = jwt_decode(this.token);
      console.log(this.data);
      console.log(this.data.user.id);
      console.log(this.profile);
    }
    this.profileService
      .getProfileById(this.profile.user._id)
      .subscribe((res) => {
        console.log(JSON.stringify(res));
        this.profile = res;
        console.log(res);
        console.log(this.profile);
        // localStorage.setItem('profiles', JSON.stringify(res));
      });
  }
}
