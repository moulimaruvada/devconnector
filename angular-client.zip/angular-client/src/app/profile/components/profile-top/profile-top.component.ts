import { Component, Input, OnInit } from '@angular/core';
import { Profiles } from 'src/app/profiles/models/profiles';

@Component({
  selector: 'app-profile-top',
  templateUrl: './profile-top.component.html',
  styleUrls: ['./profile-top.component.css'],
})
export class ProfileTopComponent implements OnInit {
  @Input() profile: Profiles;
  constructor() {}

  ngOnInit(): void {}
}
