export class EducationItem {
}
