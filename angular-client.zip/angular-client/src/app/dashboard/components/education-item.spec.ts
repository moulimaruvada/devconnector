import { EducationItem } from './education-item';

describe('EducationItem', () => {
  it('should create an instance', () => {
    expect(new EducationItem()).toBeTruthy();
  });
});
