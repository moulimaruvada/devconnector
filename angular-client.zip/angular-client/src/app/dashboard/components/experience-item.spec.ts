import { ExperienceItem } from './experience-item';

describe('ExperienceItem', () => {
  it('should create an instance', () => {
    expect(new ExperienceItem()).toBeTruthy();
  });
});
