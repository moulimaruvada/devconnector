import { Component, Input, OnInit } from '@angular/core';
import { AddEducation } from 'src/app/profile-forms/models/add-education';

@Component({
  selector: 'app-education',
  templateUrl: './education.component.html',
  styleUrls: ['./education.component.css'],
})
export class EducationComponent implements OnInit {
  @Input() educations: AddEducation[] = [];

  constructor() {}

  ngOnInit(): void {}
}
