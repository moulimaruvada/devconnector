import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { DashboardActionsComponent } from './components/dashboard-actions/dashboard-actions.component';
import { EducationComponent } from './components/education/education.component';
import { ExperienceComponent } from './components/experience/experience.component';
import { httpInterceptorProviders } from '../core/interceptors';
import { HttpClientModule } from '@angular/common/http';
import { AuthService } from '../auth/services/auth.service';
import { CreateProfileService } from '../profile-forms/services/create-profile.service';
import { ExperienceItemComponent } from './components/experience-item/experience-item.component';
import { EducationItemComponent } from './components/education-item/education-item.component';

@NgModule({
  declarations: [
    DashboardComponent,
    DashboardActionsComponent,
    EducationComponent,
    ExperienceComponent,
    ExperienceItemComponent,
    EducationItemComponent,
  ],
  imports: [CommonModule, HttpClientModule, DashboardRoutingModule],
  providers: [httpInterceptorProviders, AuthService, CreateProfileService],
})
export class DashboardModule {}
