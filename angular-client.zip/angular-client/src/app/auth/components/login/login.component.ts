import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Login } from '../../models/login';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  login: Login = new Login();

  constructor(private authService: AuthService, private router: Router) {}

  loginSubmit() {
    console.log(JSON.stringify(this.login));

    const newUser: any = {
      email: this.login.email,
      password: this.login.password,
    };
    this.authService.signInUser(newUser).subscribe(
      (res) => {
        console.log('user logged in successfully');
        this.router.navigate(['/dashboard']);
        console.log(JSON.stringify(res.token));
        localStorage.setItem('token', res.token);
        this.authService.authObservable.next('login');
      },
      (err) => {
        console.log('login failed');
      }
    );
  }

  ngOnInit(): void {}
}
