export class User {
  name: string;
  avatar: any;
}
